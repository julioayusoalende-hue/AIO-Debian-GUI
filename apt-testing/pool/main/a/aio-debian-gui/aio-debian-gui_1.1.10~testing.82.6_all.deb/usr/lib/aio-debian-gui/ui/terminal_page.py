"""Terminal page for AIO Debian GUI (GTK4 + libadwaita).

Nota: Vte 2.91 es incompatible con GTK4, por lo que se usa un
Gtk.TextView con un subprocess para ofrecer una terminal funcional.
"""

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, GLib, Adw, Gio

from aio_core import traducir, FASTFETCH_LAYOUT, comando_host, instalar_layout, restaurar_layout
import os
import subprocess
import threading


class TerminalPage(Gtk.Box):
    """Terminal integrada simplificada (GTK4 + libadwaita)."""

    def __init__(self, window):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.window = window
        self.set_margin_top(8)
        self.set_margin_bottom(8)
        self.set_margin_start(8)
        self.set_margin_end(8)

        # Toolbar
        toolbar = Gtk.Box(spacing=8)
        self.btn_fastfetch = Gtk.Button(label="Fastfetch")
        self.btn_fastfetch.connect("clicked", self._on_fastfetch)
        toolbar.append(self.btn_fastfetch)

        self.btn_clear = Gtk.Button(label=traducir("Limpiar"))
        self.btn_clear.connect("clicked", self._on_clear)
        toolbar.append(self.btn_clear)
        self.append(toolbar)

        # Área de salida
        self.text_view = Gtk.TextView(editable=False, cursor_visible=False)
        self.text_view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        self.text_buffer = self.text_view.get_buffer()
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scroll.set_vexpand(True)
        scroll.set_child(self.text_view)
        self.append(scroll)

        # Entrada de comando
        entry_box = Gtk.Box(spacing=8)
        self.entry = Gtk.Entry()
        self.entry.set_placeholder_text(traducir("Escribe un comando y pulsa Enter"))
        self.entry.connect("activate", self._on_command)
        entry_box.append(self.entry)

        self.btn_run = Gtk.Button(label=traducir("Ejecutar"))
        self.btn_run.connect("clicked", self._on_command)
        entry_box.append(self.btn_run)
        self.append(entry_box)

        self._escribir(traducir("Terminal lista. Escribe un comando."))

    def _escribir(self, texto):
        """Escribe texto en el buffer."""
        fin = self.text_buffer.get_end_iter()
        self.text_buffer.insert(fin, texto + "\n")

    def _on_clear(self, _btn):
        self.text_buffer.set_text("")

    def _on_fastfetch(self, _btn):
        self._ejecutar("fastfetch")

    def _on_command(self, _widget):
        comando = self.entry.get_text().strip()
        if not comando:
            return
        self.entry.set_text("")
        self._ejecutar(comando)

    def _ejecutar(self, comando):
        """Ejecuta un comando en un hilo y muestra la salida."""
        self._escribir(f"$ {comando}")

        def worker():
            try:
                resultado = subprocess.run(
                    comando, shell=True, capture_output=True, text=True, timeout=60,
                    cwd=os.path.expanduser("~"),
                )
                salida = resultado.stdout + resultado.stderr
                GLib.idle_add(self._escribir, salida)
            except Exception as exc:
                GLib.idle_add(self._escribir, str(exc))

        threading.Thread(target=worker, daemon=True).start()

    def on_preferences_changed(self, prefs):
        pass
