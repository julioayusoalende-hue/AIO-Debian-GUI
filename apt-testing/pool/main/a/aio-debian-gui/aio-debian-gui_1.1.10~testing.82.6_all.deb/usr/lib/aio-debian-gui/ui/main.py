#!/usr/bin/env python3
"""Entry point for AIO Debian GUI (GTK3)."""

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, Gdk, GLib, GObject, Vte, Adw, Gio

from aio_core import (
    PRGNAME, APP_ICON_NAME, POLKIT_ACTION, HELPER, HELPER_SISTEMA, GRUB_HELPER,
    APT_BACKUP_HELPER, APT_BACKUP_FILENAME, APT_BACKUP_LIMIT,
    HOMEPAGE, DEBIAN_LOGO, UBUNTU_LOGO, AYUSOS_LOGO,
    NOMBRE_AYUSOS, FASTFETCH_LAYOUT, NOTAS_VERSION,
    RECOMMENDED_ICON_DIR, BACKUP_ICON_DIR,
    IDIOMA_ACTUAL, PREFERENCIAS_DEFECTO, IDIOMAS, TEMAS,
    PASOS, GRUPOS, APPS_RECOMENDADAS, APLICACIONES_BACKUP,
    nombre_icono_recomendada, icono_recomendada,
    canales_ghostty, etiqueta, ESTILO_APLICACION,
    cabecera_mantenimiento, tarjeta_mantenimiento,
    helper_mantenimiento, usa_integracion_portable,
    helper_disponible, comando_administrativo,
    comando_pkexec, helper_admite_autorizacion_sin_contrasena,
    helper_admite_tarea, autorizacion_sin_contrasena_activa,
    novedades_version, MAX_HISTORIAL
)

from aio_core.preferences import (cargar_preferencias, guardar_preferencias,
                                  ruta_preferencias)

from aio_core.updates import (version_numerica, obtener_release_actualizacion,
                              version_app, formato_actualizacion)

from aio_core.diagnostics import run_diagnostics
from aio_core.preflight import check as run_preflight
from aio_core.scheduler import ControladorProgramacion as GtkControladorProgramacion
from aio_core.host_integration import (prepare_host, install_host,
                                       datos_distribucion_anfitrion,
                                       identidad_distribucion,
                                       logo_distribucion,
                                       imagen_logo_distribucion)
from aio_core.desktop_backup import (detect, restore, version as desktop_version,
                                     user_dirs, read as desktop_read,
                                     snapshot as desktop_snapshot, save as desktop_save, LABELS)
from aio_core.recommended_list import exportar, importar
from aio_core.fastfetch import instalar_layout, restaurar_layout
from aio_core.gtk_appearance import aplicar_tema
from aio_core.health_dashboard import create_health_dashboard
from aio_core.translations import TRADUCCIONES

from ui import main_window
from ui import home_page
from ui import software_page
from ui import terminal_page
from ui import history_dialog
from ui import diagnostics_dialog
from ui import preferences_dialog
from ui import about_dialog
from ui import recommended_page
from ui import backup_page

import os
import sys


def main():
    """Punto de entrada de la aplicación GTK3."""
    # Limpiar módulos GTK previos para evitar conflictos
    for k in list(sys.modules.keys()):
        if any(x in k.lower() for x in ['gtk', 'gdk', 'gobject', 'pango', 'vte', 'adw', 'software']):
            del sys.modules[k]

    # Inicializar GTK3
    Gtk.init()

    # Aplicación principal
    app = AioApplication(application_id='es.aiodebian.aio-debian-gui')
    app.run(sys.argv)


if __name__ == "__main__":
    main()