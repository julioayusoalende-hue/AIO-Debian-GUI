"""Header bar widget for AIO Debian GUI (GTK3 + libadwaita)."""

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, Gdk, Adw

from aio_core import (
    TRADUCCIONES, version_numerica, obtener_release_actualizacion,
    version_app, formato_actualizacion, novedades_version,
    logo_distribucion, identidad_distribucion, imagen_logo_distribucion, traducir
)


class HeaderBar(Adw.HeaderBar):
    """Custom header bar with title, version, menu and terminal button (GTK3 + libadwaita)."""

    def __init__(self, window, datos_anfitrion=None, preferencias=None, callbacks=None):
        super().__init__()
        self.window = window
        self.datos_anfitrion = datos_anfitrion or {}
        self.preferencias = preferencias or getattr(window, "preferencias", {})
        self.callbacks = callbacks or {}

        self.set_show_start_title_buttons(True)
        self.set_show_end_title_buttons(True)
        self.set_title_widget(self._build_title())

        # Botón de menú
        self.btn_menu = Gtk.MenuButton()
        self.btn_menu.set_icon_name("open-menu-symbolic")
        self.btn_menu.set_tooltip_text(traducir("Menú de preferencias"))
        popover, menu = self._create_menu()
        self.btn_menu.set_popover(popover)
        self.pack_start(self.btn_menu)

        # Botón de terminal
        self.btn_terminal = Gtk.Button()
        self.btn_terminal.set_image(Gtk.Image.new_from_icon_name("utilities-terminal-symbolic"))
        self.btn_terminal.set_always_show_image(True)
        self.btn_terminal.set_tooltip_text(traducir("Terminal"))
        self.btn_terminal.connect("clicked", self.callbacks.get("on_terminal", lambda *_: None))
        self.pack_start(self.btn_terminal)

    def _create_menu(self):
        popover = Gtk.Popover.new(self.btn_menu)
        menu = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, margin_top=8, margin_bottom=8, margin_start=8, margin_end=8)
        popover.set_child(menu)

        btn_prefs = Gtk.Button(label=traducir("Preferencias"))
        btn_prefs.connect("clicked", self.callbacks.get("on_preferences", lambda *_: None))
        menu.append(btn_prefs)

        btn_history = Gtk.Button(label=traducir("Historial de mantenimiento"))
        btn_history.connect("clicked", self.callbacks.get("on_history", lambda *_: None))
        menu.append(btn_history)

        btn_schedule = Gtk.Button(label=traducir("Programar mantenimiento"))
        btn_schedule.connect("clicked", self.callbacks.get("on_schedule", lambda *_: None))
        menu.append(btn_schedule)

        fmt = formato_actualizacion()
        if fmt in ("flatpak", "appimage"):
            btn_guide = Gtk.Button(label=traducir("Guía de integración del anfitrión"))
            btn_guide.connect("clicked", self.callbacks.get("on_host_guide", lambda *_: None))
            menu.append(btn_guide)

        btn_update = Gtk.Button(label=traducir("Buscar actualizaciones"))
        btn_update.set_tooltip_text(traducir("Actualizar esta aplicación"))
        btn_update.connect("clicked", self.callbacks.get("on_update", lambda *_: None))
        menu.append(btn_update)

        btn_about = Gtk.Button(label=traducir("Acerca de AiO Debian"))
        btn_about.connect("clicked", self.callbacks.get("on_about", lambda *_: None))
        menu.append(btn_about)

        return popover, menu

    def _build_title(self):
        titulo = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2, valign=Gtk.Align.CENTER, margin_top=3, margin_bottom=3)

        principal = Gtk.Box(spacing=8, halign=Gtk.Align.CENTER)
        nombre = Gtk.Label(label="AiO Debian")
        nombre.add_css_class("aio-header-title")
        principal.append(nombre)

        principal.append(self._version_button())

        self.channel_label = Gtk.Label(label="")
        self.channel_label.add_css_class("dim-label")
        self._update_channel_label()
        principal.append(self.channel_label)

        titulo.append(principal)

        sistema = Gtk.Box(spacing=5, halign=Gtk.Align.CENTER)
        distribucion = identidad_distribucion(self.datos_anfitrion)
        nombre_sistema = {"debian": "Debian", "ubuntu": "Ubuntu", "ayusos": "AyusOS Linux"}.get(
            distribucion, traducir("Sistema no compatible"))

        logo = imagen_logo_distribucion(self.datos_anfitrion, 16)
        if logo is not None:
            sistema.append(logo)

        version_sistema = self.datos_anfitrion.get("VERSION_ID")
        if distribucion == "ayusos" and self.datos_anfitrion.get("ID") == "debian":
            descripcion = self.datos_anfitrion.get("PRETTY_NAME", "")
            version_ayusos = re.match(r"AyusOS(?: Linux)?\s+(\d+(?:\.\d+)*)\b",
                                      descripcion, re.IGNORECASE)
            version_sistema = version_ayusos.group(1) if version_ayusos else None

        if distribucion in ("debian", "ubuntu", "ayusos") and version_sistema:
            nombre_sistema = f"{nombre_sistema} {version_sistema}"

        etiqueta_sistema = Gtk.Label(label=nombre_sistema)
        etiqueta_sistema.add_css_class("aio-header-system")
        sistema.append(etiqueta_sistema)
        titulo.append(sistema)

        return titulo

    def _version_button(self):
        version = version_app()
        base = re.split(r"[~-]", version, maxsplit=1)[0]
        texto = version_numerica(base) and version or traducir("Desarrollo")
        boton = Gtk.Button()
        boton.set_relief(Gtk.ReliefStyle.NONE)
        encabezado = traducir("Novedades de esta versión")
        boton.set_tooltip_text(encabezado)
        boton.get_accessible().set_name(f"{encabezado} · {texto}")
        numero = Gtk.Label(label=texto)
        numero.add_css_class("aio-header-version")
        boton.add_css_class("aio-header-version-button")
        boton.set_child(numero)
        boton.connect("clicked", self._on_version_clicked, version)
        return boton

    def _on_version_clicked(self, _boton, version):
        dialogo = Gtk.MessageDialog(
            transient_for=self.window,
            modal=True,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.CLOSE,
        )
        dialogo.set_title(traducir("Novedades de esta versión"))
        dialogo.set_icon_name("help-about")

        notas = novedades_version(version) or traducir("No hay notas para esta versión.")
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scrolled.set_overlay_scrolling(False)
        detalle = Gtk.TextView(editable=False, cursor_visible=False)
        detalle.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        detalle.set_left_margin(16)
        detalle.set_right_margin(16)
        detalle.set_top_margin(12)
        detalle.set_bottom_margin(12)
        detalle.set_pixels_below_lines(5)
        detalle.get_buffer().set_text(notas)
        scrolled.set_child(detalle)
        dialogo.set_child(scrolled)
        dialogo.present()

    def _update_channel_label(self):
        canal = self.preferencias.get("canal_actualizaciones", "stable")
        texto = _("Testing" if canal == "testing" else "Estable")
        self.channel_label.set_text(texto if formato_actualizacion() == "deb" else "")

    def update_preferences(self, preferencias):
        self.preferencias = preferencias
        self._update_channel_label()