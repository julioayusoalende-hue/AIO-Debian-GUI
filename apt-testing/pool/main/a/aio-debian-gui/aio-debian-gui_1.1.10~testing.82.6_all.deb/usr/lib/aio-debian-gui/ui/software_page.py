"""Software page for AIO Debian GUI (GTK4 + libadwaita)."""

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, Adw, GLib

from aio_core import traducir, comando_host, autorizacion_sin_contrasena_activa
import subprocess
import threading


class SoftwarePage(Gtk.Box):
    """Página de gestor de software (GTK4 + libadwaita)."""

    def __init__(self, window):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.window = window
        self.loaded = False
        self.busy = False

        self.set_margin_top(12)
        self.set_margin_bottom(12)
        self.set_margin_start(12)
        self.set_margin_end(12)

        # Título
        title = Gtk.Label(label=traducir("Gestor de Software"))
        title.add_css_class("aio-header-title")
        title.set_xalign(0)
        self.append(title)

        # Barra de herramientas
        toolbar = Gtk.Box(spacing=8)
        self.search_entry = Gtk.SearchEntry()
        self.search_entry.set_placeholder_text(traducir("Buscar paquetes…"))
        self.search_entry.connect("activate", self._on_search)
        toolbar.append(self.search_entry)

        self.btn_search = Gtk.Button(label=traducir("Buscar"))
        self.btn_search.add_css_class("suggested-action")
        self.btn_search.connect("clicked", self._on_search)
        toolbar.append(self.btn_search)
        self.append(toolbar)

        # Lista de resultados
        self.list_box = Gtk.ListBox()
        self.list_box.set_selection_mode(Gtk.SelectionMode.SINGLE)
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroll.set_min_content_height(300)
        scroll.set_child(self.list_box)
        self.append(scroll)

        # Estado
        self.status_label = Gtk.Label(label=traducir("Busca un paquete para ver los resultados"), xalign=0)
        self.status_label.add_css_class("dim-label")
        self.append(self.status_label)

    def _on_search(self, _widget):
        """Busca paquetes en APT."""
        query = self.search_entry.get_text().strip()
        if not query:
            return

        self.busy = True
        self.status_label.set_label(traducir("Buscando…"))
        self._limpiar_lista()

        def worker():
            try:
                salida = subprocess.run(
                    comando_host("apt-cache", "search", query),
                    capture_output=True, text=True, timeout=30,
                    env={**__import__('os').environ, "LC_ALL": "C.UTF-8"},
                ).stdout
                resultados = []
                for linea in salida.splitlines()[:50]:
                    if " - " in linea:
                        nombre, desc = linea.split(" - ", 1)
                        resultados.append((nombre.strip(), desc.strip()))
                GLib.idle_add(self._on_search_done, resultados, None)
            except Exception as exc:
                GLib.idle_add(self._on_search_done, None, str(exc))

        threading.Thread(target=worker, daemon=True).start()

    def _limpiar_lista(self):
        while True:
            child = self.list_box.get_first_child()
            if child is None:
                break
            self.list_box.remove(child)

    def _on_search_done(self, resultados, error):
        self.busy = False
        self._limpiar_lista()
        if error:
            self.status_label.set_label(traducir("Error: ") + error)
            return
        if not resultados:
            self.status_label.set_label(traducir("No se encontraron paquetes"))
            return

        for nombre, desc in resultados:
            fila = Gtk.ListBoxRow()
            caja = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            lbl_nombre = Gtk.Label(label=nombre, xalign=0)
            lbl_nombre.add_css_class("aio-task-name")
            caja.append(lbl_nombre)
            lbl_desc = Gtk.Label(label=desc, xalign=0, ellipsize=3)
            lbl_desc.add_css_class("dim-label")
            caja.append(lbl_desc)
            fila.set_child(caja)
            self.list_box.append(fila)

        self.status_label.set_label(traducir("%d paquetes encontrados") % len(resultados))
        self.loaded = True

    def _on_busy_changed(self, manager, _pspec):
        self.window._actualizar_sensibilidad()

    def set_sensitive(self, sensitive):
        self.search_entry.set_sensitive(sensitive)
        self.btn_search.set_sensitive(sensitive)

    def on_page_activated(self):
        """Se llama al activar la página."""
        if not self.loaded:
            pass

    def refresh(self):
        """Recarga la página."""
        self.loaded = False
        self._limpiar_lista()

    def focus_search(self):
        """Foca el campo de búsqueda."""
        self.search_entry.grab_focus()
