"""Task list widget for maintenance page (GTK4 + libadwaita)."""

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, GObject

from aio_core import traducir


class TaskList(Gtk.Box):
    """Lista de tareas de mantenimiento con checkboxes agrupadas por grupo (GTK4)."""

    __gsignals__ = {
        "selection-changed": (GObject.SIGNAL_RUN_FIRST, None, (object,))
    }

    def __init__(self, pasos, grupos, translate_func):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.pasos = pasos
        self.grupos = grupos
        self.translate = translate_func
        self.task_states = {}
        self.check_buttons = {}
        self.selected_tasks = set()
        self._build_ui()

    def _build_ui(self):
        for grupo_id, grupo_nombre in self.grupos:
            tareas_grupo = [p for p in self.pasos if p[4] == grupo_id]
            if not tareas_grupo:
                continue

            frame = Gtk.Frame()
            frame.add_css_class("aio-task-group")
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            box.set_margin_top(8)
            box.set_margin_bottom(8)
            box.set_margin_start(8)
            box.set_margin_end(8)
            frame.set_child(box)

            lbl_grupo = Gtk.Label(label=self.translate(grupo_nombre), xalign=0)
            lbl_grupo.add_css_class("aio-group")
            box.append(lbl_grupo)

            list_box = Gtk.ListBox()
            list_box.set_selection_mode(Gtk.SelectionMode.NONE)
            box.append(list_box)

            for task_id, titulo, descripcion, default_on, _ in tareas_grupo:
                row = Gtk.ListBoxRow()
                row.set_activatable(False)
                hbox = Gtk.Box(spacing=10, margin_top=4, margin_bottom=4)
                row.set_child(hbox)

                check = Gtk.CheckButton()
                check.add_css_class("aio-task")
                check.connect("toggled", self._on_task_toggled, task_id)
                hbox.append(check)

                info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
                name_lbl = Gtk.Label(label=self.translate(titulo), xalign=0)
                name_lbl.add_css_class("aio-task-name")
                info.append(name_lbl)

                desc_lbl = Gtk.Label(label=self.translate(descripcion), xalign=0)
                desc_lbl.add_css_class("aio-task-detail")
                desc_lbl.set_wrap(True)
                info.append(desc_lbl)

                hbox.append(info)

                self.check_buttons[task_id] = check
                list_box.append(row)

            self.append(frame)

    def _on_task_toggled(self, check, task_id):
        if check.get_active():
            self.selected_tasks.add(task_id)
        else:
            self.selected_tasks.discard(task_id)
        self.emit("selection-changed", self.selected_tasks)

    def set_task_states(self, states):
        self.task_states = states
        for task_id, check in self.check_buttons.items():
            disponible = states.get(task_id, True)
            check.set_sensitive(disponible)
            if not disponible:
                check.set_active(False)
                check.set_tooltip_text(self.translate("No disponible en esta distribución"))
            else:
                check.set_tooltip_text(None)

    def refresh_translations(self, translate_func):
        self.translate = translate_func

    def get_selected(self):
        return self.selected_tasks

    def set_sensitive(self, sensitive):
        for check in self.check_buttons.values():
            check.set_sensitive(sensitive and check.get_sensitive())
