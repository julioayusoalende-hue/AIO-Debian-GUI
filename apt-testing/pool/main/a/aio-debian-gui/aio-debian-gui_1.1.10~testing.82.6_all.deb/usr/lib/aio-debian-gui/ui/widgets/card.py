"""Card widget for AIO Debian GUI (GTK4)."""

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk

from aio_core import traducir


class Card(Gtk.Frame):
    """Tarjeta estilo aio-card con título e icono (GTK4)."""

    def __init__(self, title, icon_name, spacing=12):
        super().__init__()
        self.add_css_class("aio-card")

        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=spacing, margin_top=14, margin_bottom=14, margin_start=14, margin_end=14)
        self.set_child(content)

        header = Gtk.Box(spacing=9)
        icon = Gtk.Image.new_from_icon_name(icon_name)
        icon.set_pixel_size(16)
        icon.add_css_class("aio-icon")
        header.append(icon)

        title_lbl = Gtk.Label(label=title, xalign=0)
        title_lbl.add_css_class("aio-heading")
        header.append(title_lbl)

        content.append(header)

        self.content_box = content

    def add_widget(self, widget, expand=False, fill=False, padding=0):
        self.content_box.append(widget)

    def get_content_box(self):
        return self.content_box


def create_card(title, icon_name, spacing=12):
    """Factory function que devuelve (frame, content_box)."""
    frame = Gtk.Frame()
    frame.add_css_class("aio-card")
    content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=spacing, margin_top=14, margin_bottom=14, margin_start=14, margin_end=14)
    frame.set_child(content)

    header = Gtk.Box(spacing=9)
    icon = Gtk.Image.new_from_icon_name(icon_name)
    icon.set_pixel_size(16)
    icon.add_css_class("aio-icon")
    header.append(icon)

    title_lbl = Gtk.Label(label=title, xalign=0)
    title_lbl.add_css_class("aio-heading")
    header.append(title_lbl)

    content.append(header)

    return frame, content