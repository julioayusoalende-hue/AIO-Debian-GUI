"""Read APT and Flatpak catalogues without elevation."""

from pathlib import Path
import hashlib
import shutil
import tempfile
import os
import re
import subprocess

from .admin import APT_SOURCE, MANAGED, SOURCES, source_contents, trusted_archive

FLATPAK_REPO = 'https://dl.flathub.org/repo/flathub.flatpakrepo'
MAINTENANCE = '/usr/lib/aio-debian-gui/aio-debian-gui-helper'
ADMIN = '/usr/lib/aio-debian-gui/software_manager/admin.py'


def run(args, timeout=None, stdin=None):
    try:
        result = subprocess.run(args, stdin=stdin, timeout=timeout, text=True, encoding='utf-8', errors='replace',
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                env={**os.environ, 'LC_ALL': 'C.UTF-8'})
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError('El catálogo tardó demasiado en responder.') from exc
    if result.returncode:
        raise RuntimeError((result.stderr or result.stdout).strip()
                           or f'{args[0]} terminó con código {result.returncode}')
    return result.stdout


def preview_local_deb(filename):
    path = Path(filename)
    if path.suffix.lower() != '.deb' or not path.is_file():
        raise ValueError('Selecciona un archivo .deb local válido.')
    with tempfile.TemporaryDirectory() as directory:
        archive = Path(directory) / 'package.deb'
        with path.open('rb') as source, archive.open('wb') as target:
            shutil.copyfileobj(source, target)
        with archive.open('rb') as source:
            checksum = hashlib.sha256()
            for block in iter(lambda: source.read(1024 * 1024), b''):
                checksum.update(block)
            digest = checksum.hexdigest()
        metadata = run(['/usr/bin/dpkg-deb', '-f', str(archive), 'Package', 'Version',
                        'Architecture', 'Description', 'Pre-Depends', 'Depends'])
        package = run(['/usr/bin/dpkg-deb', '-f', str(archive), 'Package']).strip()
        trusted = trusted_archive(package, digest)
        plan = run(['/usr/bin/apt-get', '-s', '--no-remove', 'install', '--', str(archive)])
    return digest, package, trusted, metadata + '\n' + plan


def install_local_deb(filename, command):
    with open(filename, 'rb') as source:
        return run(command, stdin=source)


def debs():
    rows = []
    for line in run(['/usr/bin/apt', 'list']).splitlines()[1:]:
        fields = line.split(maxsplit=3)
        if len(fields) < 3 or '/' not in fields[0]:
            continue
        package, version, arch = fields[0].split('/', 1)[0], fields[1], fields[2]
        apt_state = fields[3] if len(fields) == 4 else ''
        state = ('Actualizable' if '[upgradable' in apt_state else
                 'Instalado' if '[installed' in apt_state else 'Disponible')
        identifier = package if arch == 'all' else f'{package}:{arch}'
        rows.append((package, identifier, version, state, arch))
    return rows, []


def _deb822_records(output):
    for stanza in re.split(r'\n[ \t]*\n', output):
        fields = {}
        key = None
        for line in stanza.splitlines():
            if line.startswith((' ', '\t')):
                if key in ('Pre-Depends', 'Depends', 'Recommends'):
                    fields[key] += ' ' + line.strip()
                continue
            key, separator, value = line.partition(':')
            if separator:
                fields[key] = value.strip()
            else:
                key = None
        if fields:
            yield fields


def deb_details(identifier, version, arch):
    name = identifier.split(':', 1)[0]

    def find_record(output):
        return next((record for record in _deb822_records(output)
                     if record.get('Package') == name and record.get('Version') == version
                     and record.get('Architecture') == arch), None)

    try:
        output = run(['/usr/bin/apt-cache', 'show', '--', f'{identifier}={version}'], timeout=8)
        record = find_record(output)
    except RuntimeError:
        record = None
    if record is None:
        record = find_record(run(['/usr/bin/dpkg-query', '-s', '--', identifier], timeout=8))
    if record is None:
        return {}
    details = {key: record[key] for key in
               ('Architecture', 'Version', 'Pre-Depends', 'Depends', 'Recommends', 'Section', 'Homepage')
               if record.get(key)}
    description = record.get('Description') or record.get('Description-en')
    if description:
        details['Description'] = description
    for source, field, unit in (('Size', 'Download Size', 'B'),
                                ('Installed-Size', 'Installed Size', 'KiB')):
        size = record.get(source, '')
        if size.isdecimal():
            details[field] = f'{size} {unit}'
    return details


def flatpak_details(scope, remote, ref, installed):
    args = ('info', '--', ref) if installed else ('remote-info', '--', remote, ref)
    output = run(flatpak(scope, *args), timeout=12).strip()
    # With LC_ALL=C.UTF-8, the human-readable report starts with an optional
    # AppStream summary and then prints the English field labels.
    report = re.search(r'^[ \t]*ID:', output, flags=re.MULTILINE)
    summary = output[:report.start()] if report else ''
    fields = output[report.end():] if report else output
    details = {}
    _, found, description = ' '.join(summary.split()).partition(' - ')
    if found and description not in ('(null)', '-'):
        details['Description'] = description
    keys = {'Runtime', 'Arch', 'Branch', 'Version', 'License', 'Download Size', 'Installed Size'}
    for line in fields.splitlines():
        key, _, value = line.strip().partition(':')
        if key in keys and value.strip() not in ('', '-'):
            details['Architecture' if key == 'Arch' else key] = value.strip()
    return details


def flatpak(scope, *args):
    return ['/usr/bin/flatpak', f'--{scope}', *args]


def columns(output, size):
    for line in output.splitlines():
        values = line.split('\t')
        if len(values) <= size:
            yield values + [""] * (size - len(values))


def remotes(scope):
    output = run(flatpak(scope, 'remotes', '--columns=name,url,options'))
    return list(columns(output, 3))


def flatpaks(scope):
    rows = {}
    errors = []
    for name, ref, version, origin in columns(run(flatpak(
            scope, 'list', '--app', '--columns=name,ref,version,origin')), 4):
        rows[(origin, ref)] = (name, ref, version, 'Instalado', origin)
    installed_origins = {origin for origin, _ in rows}
    for remote, _, options in remotes(scope):
        if 'disabled' in options.split(','):
            continue
        try:
            output = run(flatpak(scope, 'remote-ls', '--app',
                                 '--columns=name,ref,version', remote), timeout=12)
            for name, ref, version in columns(output, 3):
                rows.setdefault((remote, ref), (name, ref, version, 'Disponible', remote))
            if remote in installed_origins:
                updates = run(flatpak(scope, 'remote-ls', '--app', '--updates', '--all',
                                      '--arch=*', '--columns=ref', '--', remote), timeout=12)
                for (ref,) in columns(updates, 1):
                    key = (remote, ref)
                    row = rows.get(key)
                    if row and row[3] == 'Instalado':
                        rows[key] = (*row[:3], 'Actualizable', remote)
        except RuntimeError as exc:
            errors.append(f'{remote} — {exc}')
    return sorted(rows.values(), key=lambda row: row[0].casefold()), errors


def repos(scope):
    rows = [(name, url, 'Flatpak', 'Desactivado' if 'disabled' in options.split(',')
             else 'Activo', name) for name, url, options in remotes(scope)]
    paths = [Path('/etc/apt/sources.list'), Path('/etc/apt/sources.list.disabled'),
             *sorted(SOURCES.glob('*'))]
    for path in paths:
        if not APT_SOURCE.fullmatch(path.name) and path.parent == SOURCES:
            continue
        try:
            contents = path.read_text()
        except OSError:
            continue
        managed = bool(MANAGED.fullmatch(path.name))
        file_disabled = path.suffix == '.disabled'
        location = str(path) if path.parent != SOURCES else path.name
        if path.name.endswith(('.list', '.list.disabled')):
            for line in contents.splitlines():
                match = re.match(r'^\s*(#\s*)?deb(?:-src)?\s+(?:\[[^\]]*\]\s+)?(\S+)(?:\s+(\S+))?', line)
                if match:
                    rows.append((match[3] or path.name, match[2], 'APT',
                                 'En pausa' if file_disabled else 'Desactivado' if match[1] else 'Activo',
                                 location))
            continue
        for stanza in re.split(r'\n\s*\n', contents):
            uri = re.search(r'^URIs:\s*(.+)$', stanza, re.MULTILINE | re.IGNORECASE)
            suite = re.search(r'^Suites:\s*(.+)$', stanza, re.MULTILINE | re.IGNORECASE)
            if not uri:
                continue
            disabled = re.search(
                r'^Enabled:\s*no\s*$', stanza, re.MULTILINE | re.IGNORECASE)
            rows.append((suite[1] if suite else path.name, uri[1],
                         'APT • gestionado' if managed else 'APT',
                         'En pausa' if file_disabled else 'Desactivado' if disabled else 'Activo',
                         location))
    return rows, []


# ---------------------------------------------------------------------------
# MEJORAS (Opción 2): capacidades nuevas añadidas SIN eliminar las funciones originales.
# Todas devuelven (rows, errors) para ser compatibles con el manager existente.
# ---------------------------------------------------------------------------

_DEB_ENRICH_DESCRIPTIONS = {}
_DEB_ENRICH_SECTIONS = {}


def debs_catalogue():
    """Catálogo DEB enriquecido con descripciones y secciones."""
    rows = []
    descriptions = _DEB_ENRICH_DESCRIPTIONS
    sections = _DEB_ENRICH_SECTIONS
    for line in run(['/usr/bin/apt', 'list']).splitlines()[1:]:
        fields = line.split(maxsplit=3)
        if len(fields) < 3 or '/' not in fields[0]:
            continue
        package, version, arch = fields[0].split('/', 1)[0], fields[1], fields[2]
        apt_state = fields[3] if len(fields) == 4 else ''
        state = ('Actualizable' if '[upgradable' in apt_state else
                 'Instalado' if '[installed' in apt_state else 'Disponible')
        identifier = package if arch == 'all' else f'{package}:{arch}'
        rows.append((package, identifier, version, state, arch))
    try:
        for record in _deb822_records(run(['/usr/bin/apt-cache', 'show'])):
            name = record.get('Package', '')
            if name:
                if name not in descriptions:
                    desc = (record.get('Description') or record.get('Description-en') or '').strip()
                    if desc:
                        descriptions[name] = desc
                if name not in sections:
                    section = record.get('Section', '')
                    if section:
                        sections[name] = section.split('/')[-1]
    except (RuntimeError, OSError, ValueError):
        pass
    return rows, []


def flatpaks_catalogue(scope):
    """Catálogo Flatpak enriquecido con actualizaciones."""
    rows = {}
    errors = []
    installed_origins = set()
    for name, ref, version, origin in columns(run(flatpak(
            scope, 'list', '--app', '--columns=name,ref,version,origin')), 4):
        rows[(origin, ref)] = (name, ref, version, 'Instalado', origin)
        installed_origins.add(origin)
    for remote, _, options in remotes(scope):
        if 'disabled' in options.split(','):
            continue
        try:
            output = run(flatpak(scope, 'remote-ls', '--app',
                                 '--columns=name,ref,version', remote), timeout=12)
            for name, ref, version in columns(output, 3):
                rows.setdefault((remote, ref), (name, ref, version, 'Disponible', remote))
            if remote in installed_origins:
                updates_out = run(flatpak(scope, 'remote-ls', '--app', '--updates', '--all',
                                          '--arch=*', '--columns=ref,version', '--', remote), timeout=12)
                for ref, version in columns(updates_out, 2):
                    if ref:
                        key = (remote, ref)
                        row = rows.get(key)
                        if row and row[3] == 'Instalado':
                            rows[key] = (*row[:3], 'Actualizable', remote)
        except RuntimeError as exc:
            errors.append(f'{remote} — {exc}')
    return sorted(rows.values(), key=lambda row: row[0].casefold()), errors


def get_deb_section(package_name):
    """Obtiene la sección de un paquete DEB."""
    try:
        output = run(['/usr/bin/apt-cache', 'show', package_name])
        for record in _deb822_records(output):
            if record.get('Package') == package_name:
                section = record.get('Section', '')
                if section:
                    return section.split('/')[-1]
    except Exception:
        pass
    return 'unknown'


class SearchIndex:
    """Índice de búsqueda simple para paquetes."""

    def __init__(self):
        self._index = {}
        self._packages = []

    def build(self, rows, descriptions=None, sections=None):
        self._index.clear()
        self._packages = rows
        descriptions = descriptions or _DEB_ENRICH_DESCRIPTIONS
        sections = sections or _DEB_ENRICH_SECTIONS
        for i, (name, identifier, version, state, arch) in enumerate(rows):
            self._add_token(name.lower(), i)
            desc = descriptions.get(name, '')
            for word in desc.split():
                if len(word) > 2:
                    self._add_token(word.lower(), i)
            section = sections.get(name, '')
            if section:
                self._add_token(section.lower(), i)

    def _add_token(self, token, idx):
        if token not in self._index:
            self._index[token] = set()
        self._index[token].add(idx)

    def search(self, query):
        tokens = [t.lower() for t in query.split() if len(t) > 1]
        if not tokens:
            return list(range(len(self._packages)))
        results = None
        for token in tokens:
            matches = set()
            for idx_token, indices in self._index.items():
                if idx_token.startswith(token):
                    matches.update(indices)
            if results is None:
                results = matches
            else:
                results &= matches
            if not results:
                return []
        return sorted(results) if results else []


search_index = SearchIndex()


def analyze_deb_file(filepath):
    """Analiza un archivo .deb local para drag & drop."""
    from dataclasses import dataclass

    @dataclass
    class DebFileInfo:
        path: str
        package: str
        version: str
        architecture: str
        description: str
        depends: str
        pre_depends: str
        trusted: bool
        install_plan: str
        sha256: str

    path = Path(filepath)
    if path.suffix.lower() != '.deb' or not path.is_file():
        raise ValueError('No es un archivo .deb válido.')
    with tempfile.TemporaryDirectory() as directory:
        archive = Path(directory) / 'package.deb'
        with path.open('rb') as source, archive.open('wb') as target:
            shutil.copyfileobj(source, target)
        with archive.open('rb') as source:
            checksum = hashlib.sha256()
            for block in iter(lambda: source.read(1024 * 1024), b''):
                checksum.update(block)
            digest = checksum.hexdigest()
        metadata = run(['/usr/bin/dpkg-deb', '-f', str(archive), 'Package', 'Version',
                        'Architecture', 'Description', 'Pre-Depends', 'Depends'])
        package = run(['/usr/bin/dpkg-deb', '-f', str(archive), 'Package']).strip()
        trusted = trusted_archive(package, digest)
        plan = run(['/usr/bin/apt-get', '-s', '--no-remove', 'install', '--', str(archive)])
    lines = metadata.strip().split('\n')
    info = {}
    current_key = None
    for line in lines:
        if ':' in line and not line.startswith(' '):
            key, val = line.split(':', 1)
            info[key.strip()] = val.strip()
            current_key = key.strip()
        elif current_key and line.startswith(' '):
            info[current_key] += ' ' + line.strip()
    return DebFileInfo(
        path=filepath,
        package=info.get('Package', package),
        version=info.get('Version', ''),
        architecture=info.get('Architecture', ''),
        description=info.get('Description', ''),
        depends=info.get('Depends', ''),
        pre_depends=info.get('Pre-Depends', ''),
        trusted=trusted,
        install_plan=plan,
        sha256=digest,
    )
