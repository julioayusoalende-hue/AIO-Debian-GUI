"""About dialog (GTK4 + libadwaita)."""

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, Adw

from aio_core import traducir, version_app, HOMEPAGE


class AboutDialog(Adw.AboutDialog):
    """Diálogo Acerca de (GTK4 + libadwaita)."""

    def __init__(self, parent=None):
        super().__init__()
        self.set_transient_for(parent)
        self.set_modal(True)
        self.set_program_name("AiO Debian")
        self.set_version(version_app())
        self.set_website(HOMEPAGE)
        self.set_copyright("© 2026 AIO Debian Team")
        self.set_artists(["AIO Debian Team"])
        self.set_comments(traducir("Interfaz gráfica de mantenimiento y configuración para Debian y Ubuntu LTS"))
        self.present()
