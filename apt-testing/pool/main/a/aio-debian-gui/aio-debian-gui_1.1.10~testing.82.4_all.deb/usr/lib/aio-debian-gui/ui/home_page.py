"""Home page for AIO Debian GUI (GTK4 + libadwaita)."""

# FORZADO: import gi y require_version DEBEN ser las PRIMERAS instrucciones absolutas,
# sin ningún import, assignment o comentario que los preceda.
import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, GLib, Adw

# A partir de aquí: imports de la aplicación (no tocan el namespace GTK)
from aio_core import constants, fastfetch, gtk_appearance, traductor
from aio_core import version_app, formato_actualizacion, datos_distribucion_anfitrion
from aio_core import identidad_distribucion, logo_distribucion, imagen_logo_distribucion, distribuidor_so
from aio_core import traducir, timer_utils, PREFERENCIAS_DEFECTO, PREFERENCIAS_USUARIO, IDIOMA_ACTUAL, IDIOMAS, TEMAS
from aio_core import notas_version, KERNEL, EDITOR, SHELL, MIRA, EDITOR_BASE, DEPARTAMENTOS, PREGUNTAS, ESTADOS_SISTEMA, HISTORIAL
from aio_core import es_flatpak, comando_host, leer_texto, paquete_instalado, version_app
from aio_core import paquete_instalado, version_app, formato_actualizacion, datos_distribucion_anfitrion
from aio_core import distribucion_anfitrion, identidad_distribucion, logo_distribucion, imagen_logo_distribucion
from aio_core import NOTAS_VERSION, RECOMMENDED_ICON_DIR, BACKUP_ICON_DIR, TEMAS

from aio_core import constants as aio_constants

from ui.widgets.card import Card
from ui.widgets.queue_widget import QueueWidget


class HomePage(Adw.Baseline):
    """Página de inicio estilo tablero (GTK4 + libadwaita)."""

    def __init__(self, window):
        super().__init__()
        self.window = window
        self.set_spacing(12)
        self.set_margin_top(12)
        self.set_margin_bottom(12)
        self.set_margin_start(12)
        self.set_margin_end(12)

        # Tarjetas principales (Fastfetch-style + sistema)
        # Fila 1: Hardware + Snap
        self.hardware_card = Card(traducir("Hardware"), "computer")
        self.append(self.hardware_card)
        self.snap_card = Card(traducir("Snap"), "snap")
        self.append(self.snap_card)

        # Fila 2: Distribución + Kernel
        self.distro_card = Card(traducir("Distribución"), "os")
        self.append(self.distro_card)
        self.kernel_card = Card(traducir("Kernel"), "kernel")
        self.append(self.kernel_card)

        # Fila 3: Actualizaciones + Espacio
        self.updates_card = Card(traducir("Actualizaciones"), "system-software-update")
        self.append(self.updates_card)
        # Espacio vacío para balanceo
        spacer = Gtk.Box()
        self.attach(spacer, 2, 2, 1, 1)

        # Inicializar datos
        GLib.idle_add(self._actualizar_datos_iniciales)

    def _actualizar_datos_iniciales(self):
        """Actualiza los datos de las tarjetas en la página de inicio."""
        try:
            datos = fastfetch.get_system_info()
            if datos:
                # Actualizar hardware card
                info_text = datos.get("hardware", {}).get("model", "")
                if info_text:
                    # Acceder al content_box de la tarjeta
                    for child in self.hardware_card.get_children():
                        if hasattr(child, 'get_children'):
                            for grandchild in child.get_children():
                                pass  # Simplificado

                # Actualizar distribución card
                distro_info = identidad_distribucion(datos.get("anfitrion", {})) if datos else ""
                if distro_info:
                    self.distro_card.get_content_box().remove(self.distro_card.get_children()[0] if self.distro_card.get_children() else None)
                    lbl = Gtk.Label(label=distro_info)
                    lbl.add_css_class("aio-heading")
                    self.distro_card.get_content_box().append(lbl)

                # Actualizar kernel card
                kernel = datos.get("kernel", "") if datos else ""
                if kernel:
                    self.kernel_card.get_content_box().remove(self.kernel_card.get_children()[0] if self.kernel_card.get_children() else None)
                    lbl = Gtk.Label(label=kernel)
                    lbl.add_css_class("aio-heading")
                    self.kernel_card.get_content_box().append(lbl)
        except Exception as e:
            print(f"Error updating home page data: {e}")
        return False  # No repetir

    def actualizar_todas_las_tarjetas(self):
        """Actualiza todas las tarjetas (llamar desde el window)."""
        GLib.idle_add(self._actualizar_datos_iniciales)
        try:
            # Actualizar tarjeta Snap
            snap_instalado = shutil.which("snap") is not None
            snap_lbl = Gtk.Label(label="Sí" if snap_instalado else "No")
            snap_lbl.add_css_class("dim-label")
            # Reemplazar o actualizar el contenido de snap_card
            children = self.snap_card.get_children()
            if children:
                self.snap_card.get_children()[0].set_label(snap_lbl.get_text())
            else:
                self.snap_card.get_content_box().add(snap_lbl)
        except Exception as e:
            print(f"Error actualizando snap card: {e}")

    def actualizar_tarjeta_actualizaciones(self):
        """Actualiza la tarjeta de actualizaciones (versión disponible)."""
        GLib.idle_add(self._check_updates_lazy)

    def _check_updates_lazy(self):
        """Verifica actualizaciones de forma perezosa."""
        try:
            from aio_core import formato_actualizacion
            fmt = formato_actualizacion()
            # Mostrar estado básico
            self.updates_card.get_content_box().remove(self.updates_card.get_children()[0] if self.updates_card.get_children() else None)
            lbl = Gtk.Label(label="Verificar" if fmt == "deb" else "Versión disponible")
            lbl.add_css_class("dim-label")
            self.updates_card.get_content_box().append(lbl)
        except Exception as e:
            print(f"Error checking updates: {e}")
        return False

    def limpiar(self):
        """Limpia la página."""
        for child in self.get_children():
            self.remove(child)
        # Recrear estructura básica
        self._setup_cards()

    def _setup_cards(self):
        """Recrear todas las tarjetas."""
        self.hardware_card = Card(traducir("Hardware"), "computer")
        self.append(self.hardware_card)
        self.snap_card = Card(traducir("Snap"), "snap")
        self.append(self.snap_card)
        self.distro_card = Card(traducir("Distribución"), "os")
        self.append(self.distro_card)
        self.kernel_card = Card(traducir("Kernel"), "kernel")
        self.append(self.kernel_card)
        self.updates_card = Card(traducir("Actualizaciones"), "system-software-update")
        self.append(self.updates_card)
        spacer = Gtk.Box()
        self.attach(spacer, 2, 2, 1, 1)