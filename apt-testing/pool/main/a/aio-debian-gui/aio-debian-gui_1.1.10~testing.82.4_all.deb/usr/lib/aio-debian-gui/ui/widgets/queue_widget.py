"""Queue widget for software manager (GTK4)."""

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, GObject


class QueueWidget(Gtk.Frame):
    """Widget para mostrar y gestionar cola de operaciones (GTK4)."""

    def __init__(self, translate_func):
        super().__init__()
        self.translate = translate_func
        self.queue = []
        self.set_visible(False)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6, margin_top=8, margin_bottom=8, margin_start=8, margin_end=8)
        self.set_child(box)

        self.title_label = Gtk.Label(xalign=0)
        self.title_label.add_css_class("aio-task-name")
        box.append(self.title_label)

        self.list_box = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
        self.list_box.set_activate_on_single_click(False)
        scroll = Gtk.ScrolledWindow(max_content_height=180, propagate_natural_height=True)
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroll.set_child(self.list_box)
        box.append(scroll)

        actions = Gtk.Box(spacing=6)
        self.apply_btn = Gtk.Button()
        self.apply_btn.add_css_class("suggested-action")
        self.apply_btn.connect("clicked", lambda *_: self.emit("apply"))
        self.clear_btn = Gtk.Button()
        self.clear_btn.connect("clicked", lambda *_: self.emit("clear"))
        actions.append(self.apply_btn)
        actions.append(self.clear_btn)
        box.append(actions)

        self._update_labels()

    def add_item(self, item):
        if any(q["identifier"] == item["identifier"] for q in self.queue):
            return False

        self.queue.append(item)
        self._rebuild_list()
        self._update_labels()
        return True

    def remove_item(self, index):
        if 0 <= index < len(self.queue):
            del self.queue[index]
            self._rebuild_list()
            self._update_labels()

    def clear(self):
        self.queue.clear()
        self._rebuild_list()
        self._update_labels()

    def get_items(self):
        return list(self.queue)

    def _rebuild_list(self):
        while True:
            child = self.list_box.get_first_child()
            if child is None:
                break
            self.list_box.remove(child)

        for index, item in enumerate(self.queue):
            row = Gtk.Box(spacing=8, margin_top=2, margin_bottom=2)
            verbs = {"install": self.translate("Instalar"),
                     "upgrade": self.translate("Actualizar"),
                     "remove": self.translate("Desinstalar")}
            label = Gtk.Label(label=f"{verbs.get(item['action'], item['action'])} {item['name']}",
                              xalign=0, ellipsize=3)
            label.set_tooltip_text(item["identifier"])
            row.append(label)

            remove_btn = Gtk.Button(label="×")
            remove_btn.set_relief(Gtk.ReliefStyle.NONE)
            remove_btn.set_tooltip_text(self.translate("Quitar de la cola"))
            remove_btn.connect("clicked", lambda *_args, pos=index: self.remove_item(pos))
            row.append(remove_btn)

            self.list_box.append(row)

    def _update_labels(self):
        count = len(self.queue)
        self.title_label.set_label(self.translate("Cola de operaciones · %d operaciones") % count)
        self.apply_btn.set_label(self.translate("Aplicar cola (%d)") % count)
        self.clear_btn.set_label(self.translate("Vaciar cola"))
        self.set_visible(count > 0)

    def set_apply_callback(self, callback):
        self.apply_btn.connect("clicked", lambda *_: callback())

    def set_clear_callback(self, callback):
        self.clear_btn.connect("clicked", lambda *_: callback())