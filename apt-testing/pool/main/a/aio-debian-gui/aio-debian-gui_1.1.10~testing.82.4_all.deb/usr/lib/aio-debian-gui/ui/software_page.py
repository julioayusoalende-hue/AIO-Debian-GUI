"""Software page for AIO Debian GUI (GTK4 + libadwaita)."""

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, Adw

from aio_core import traduzir, autorizacion_sin_contrasena_activa

# Software manager - usar la versión clásica compatible con testing
try:
    from software_manager.manager import SoftwareManagerPage
    HAS_SOFTWARE_MANAGER = True
except ImportError:
    HAS_SOFTWARE_MANAGER = False


class SoftwarePage(Gtk.Box):
    """Página de gestor de software (GTK4 + libadwaita)."""

    def __init__(self, window):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.window = window
        self.set_spacing(12)
        self.set_margin_top(12)
        self.set_margin_bottom(12)
        self.set_margin_start(12)
        self.set_margin_end(12)

        # Título
        title = Gtk.Label(label=traduzir("Gestor de Software"))
        title.add_css_class("aio-header-title")
        self.add(title)

        # Usar SoftwareManagerPage clásico si está disponible
        if HAS_SOFTWARE_MANAGER:
            self.manager = SoftwareManagerPage(window, traduzir, autorizacion_sin_contrasena_activa)
            self.add(self.manager)
            self.manager.connect("notify::busy", self._on_busy_changed)
        else:
            # Fallback: mensaje informativo
            label = Gtk.Label(label=traduzir("Gestor de software no disponible"))
            label.add_css_class("dim-label")
            self.add(label)

        # Nota sobre loading
        self.loaded = False

    def _on_busy_changed(self, manager, _pspec):
        """Actualiza sensibilidad de la ventana cuando el manager está ocupado."""
        self.window._update_sensitivity()

    def set_sensitive(self, sensitive):
        """Propaga sensibilidad al manager."""
        if hasattr(self, 'manager'):
            self.manager.set_sensitive(sensitive)

    def on_page_activated(self):
        """Se llama al activar la pestaña."""
        if hasattr(self, 'manager') and not self.manager.loaded:
            self.manager.load()

    def refresh(self):
        """Recarga la página de software."""
        if hasattr(self, 'manager') and hasattr(self.manager, 'load'):
            self.manager.load(force=True)

    def focus_search(self):
        """Foca el campo de búsqueda del manager."""
        if hasattr(self, 'manager') and hasattr(self.manager, 'search_entry'):
            self.manager.search_entry.grab_focus()