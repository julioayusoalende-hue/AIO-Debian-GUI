"""Main window for AIO Debian GUI (GTK4 + libadwaita)."""

import os
import sys
import threading
import subprocess
import shutil
import re

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
gi.require_version("Vte", "2.91")
from gi.repository import Gtk, Gdk, GLib, GObject, Vte, Pango, Adw

# Core imports - from specific modules
from aio_core.clock import sincronizar as core_clock
from aio_core.history import (MAX_HISTORIAL, ruta_historial, leer_historial,
                               guardar_registro_mantenimiento)
from aio_core.preferences import (cargar_preferencias, guardar_preferencias,
                                   ruta_preferencias)
from aio_core.updates import (version_numerica, obtener_release_actualizacion,
                               version_app, formato_actualizacion)
from aio_core.diagnostics import run_diagnostics
from aio_core.preflight import check as run_preflight
from aio_core.scheduler import ControladorProgramacion as core_scheduler
from aio_core.host_integration import (prepare_host, install_host,
                                        datos_distribucion_anfitrion,
                                        identidad_distribucion,
                                        logo_distribucion,
                                        imagen_logo_distribucion)
from aio_core.desktop_backup import (detect, restore, version as desktop_version,
                                     user_dirs, read as desktop_read,
                                     snapshot as desktop_snapshot, save as desktop_save, LABELS)
from aio_core.recommended_list import exportar, importar
from aio_core.fastfetch import instalar_layout, restaurar_layout
from aio_core.gtk_appearance import aplicar_tema
from aio_core.gtk_scheduler import ControladorProgramacion as GtkControladorProgramacion
from aio_core.health_dashboard import create_health_dashboard
from aio_core.translations import TRADUCCIONES

# Constants and utilities
from aio_core.constants import (PRGNAME, APP_ICON_NAME, POLKIT_ACTION, HELPER,
                                 HELPER_SISTEMA, GRUB_HELPER, APT_BACKUP_HELPER,
                                 APT_BACKUP_FILENAME, APT_BACKUP_LIMIT,
                                 HOMEPAGE, DEBIAN_LOGO, UBUNTU_LOGO, AYUSOS_LOGO,
                                 NOMBRE_AYUSOS, FASTFETCH_LAYOUT, NOTAS_VERSION,
                                 RECOMMENDED_ICON_DIR, BACKUP_ICON_DIR,
                                 IDIOMA_ACTUAL, PREFERENCIAS_DEFECTO, IDIOMAS, TEMAS,
                                 PASOS, GRUPOS, APPS_RECOMENDADAS, APLICACIONES_BACKUP,
                                 nombre_icono_recomendada, icono_recomendada,
                                 canales_ghostty, etiqueta, ESTILO_APLICACION,
                                 cabecera_mantenimiento, tarjeta_mantenimiento,
                                 helper_mantenimiento, usa_integracion_portable,
                                 helper_disponible, comando_administrativo,
                                 comando_pkexec, helper_admite_autorizacion_sin_contrasena,
                                 helper_admite_tarea, autorizacion_sin_contrasena_activa,
                                 novedades_version, MAX_HISTORIAL)

# UI widgets imports
from .widgets.header_bar import HeaderBar
from .maintenance_page import MaintenancePage
from .software_page import SoftwarePage
from .recommended_page import RecommendedPage
from .backup_page import BackupPage
from .home_page import HomePage
from .terminal_page import TerminalPage
from .preferences_dialog import PreferencesDialog
from .diagnostics_dialog import DiagnosticsDialog
from .about_dialog import AboutDialog

# Software manager
try:
    from software_manager.manager import SoftwareManagerPage
    HAS_SOFTWARE_MANAGER = True
except ImportError:
    HAS_SOFTWARE_MANAGER = False


class VentanaPrincipal(Adw.ApplicationWindow):
    """Ventana principal de AIO Debian GUI (GTK4 + libadwaita)."""

    def __init__(self, app, preferencias=None):
        super().__init__(application=app)
        self.app = app
        self.preferencias = (preferencias or PREFERENCIAS_DEFECTO).copy()
        self.destruida = False
        self.connect("destroy", self._on_destroy)

        global IDIOMA_ACTUAL
        IDIOMA_ACTUAL = self.preferencias["idioma"]

        self.set_default_size(1160, 780)
        self.set_title("AiO Debian")
        self.set_icon_name(APP_ICON_NAME)

        # Estado general
        self.en_curso = False
        self.proceso = None
        self.flujo = None
        self.necesita_reinicio = False
        self.servicios_pendientes = set()
        self.hubo_errores = False
        self.fin_recibido = False
        self.terminado_gestionado = False
        self.configurando_sin_contrasena = None
        self.actualizando_sin_contrasena = False
        self.esperando_autorizacion = False
        self.cancelacion_autorizacion = None
        self.timeout_autorizacion_id = None
        self.consultando_estados = False
        self.timeout_estados_id = None
        self.estados_tareas = set()
        self.nvidia_presente = False
        self.nvidia_hibrida = False
        self.nvidia_instalada = False
        self.nvidia_candidata = "no-disponible"
        self.nvidia_secureboot = "desconocido"
        self.salida_estados = []
        self.comprobando_actualizacion = False
        self.backup_action_in_progress = False
        self.grub_action_in_progress = False

        # Aplicar tema inicial
        gtk_appearance.aplicar_tema(self.preferencias.get("tema", "sistema"))

        # Construir UI
        self._construir_ui()
        self._actualizar_estados_iniciales()
        self._construir_cuerpo()
        self._inicializar_tareas()

    def _on_destroy(self, _widget):
        self.destruida = True
        if self.proceso:
            try:
                self.proceso.terminate()
            except Exception:
                pass

    def _construir_ui(self):
        """Construye la interfaz principal con NavigationView."""
        # NavigationView como contenedor principal
        self.nav_view = Adw.NavigationView()
        self.set_content(self.nav_view)

        # Header bar personalizada
        self.header_bar = HeaderBar(self)
        self.set_titlebar(self.header_bar)

        # Toast overlay para notificaciones
        self.toast_overlay = Adw.ToastOverlay()
        self.toast_overlay.set_child(self.nav_view)
        self.set_content(self.toast_overlay)

        # Página inicial
        self.home_page = HomePage(self)
        self.nav_view.push(self.home_page)

    def _construir_cuerpo(self):
        """Inicializa las páginas principales (lazy loading)."""
        self.maintenance_page = None
        self.software_page = None
        self.recommended_page = None
        self.backup_page = None
        self.terminal_page = None
        self.pagina_software = None  # compatibilidad legacy

    def _actualizar_estados_iniciales(self):
        """Actualiza estados iniciales (hardware, snapd, etc.)."""
        # Detectar hardware NVIDIA
        try:
            self._detectar_nvidia()
        except Exception:
            pass

        # Verificar snapd
        self.snapd_presente = shutil.which("snap") is not None

        # Verificar si hay actualizaciones disponibles
        self._verificar_actualizaciones_inicial()

    def _inicializar_tareas(self):
        """Inicializa tareas periódicas."""
        # Sincronizar reloj si es la primera vez
        if not self.preferencias.get("reloj_inicial_sincronizado", False):
            GLib.idle_add(self._sincronizar_reloj_inicial)

        # Verificar actualizaciones en segundo plano
        GLib.timeout_add_seconds(30, self._verificar_actualizaciones_periodico)

    def _sincronizar_reloj_inicial(self):
        if self.destruida:
            return
        try:
            core_clock()
            self.preferencias["reloj_inicial_sincronizado"] = True
            guardar_preferencias(self.preferencias)
        except Exception:
            pass
        return False  # No repetir

    def _verificar_actualizaciones_inicial(self):
        """Verifica actualizaciones al inicio."""
        pass  # Se hará en segundo plano

    def _verificar_actualizaciones_periodico(self):
        """Verifica actualizaciones periódicamente."""
        if not self.destruida and not self.en_curso and not self.comprobando_actualizacion:
            self._check_update_silent()
        return True  # Repetir cada 30s

    def _check_update_silent(self):
        """Verifica actualizaciones en silencio."""
        pass  # Implementar si necesario

    def _detectar_nvidia(self):
        """Detecta GPU NVIDIA."""
        try:
            salida = subprocess.run(
                ["lspci", "-nn"], capture_output=True, text=True, timeout=5
            ).stdout
            for linea in salida.splitlines():
                if "NVIDIA" in linea and ("VGA" in linea or "3D" in linea):
                    self.nvidia_presente = True
                    break
        except Exception:
            pass

    # --- Métodos de navegación ---

    def ir_a_pagina(self, pagina):
        """Navega a una página en el NavigationView."""
        if self.nav_view and pagina:
            self.nav_view.push(pagina)

    def volver(self):
        """Vuelve a la página anterior."""
        if self.nav_view:
            self.nav_view.pop()

    def ir_a_inicio(self):
        """Vuelve a la página de inicio."""
        while self.nav_view.get_depth() > 1:
            self.nav_view.pop()

    # --- Métodos de estado y sensibilidad ---

    def _actualizar_sensibilidad(self):
        """Actualiza sensibilidad de botones según estado."""
        sensible = not (self.en_curso or self.programando or self.comprobando_actualizacion)
        if hasattr(self, 'header_bar'):
            self.header_bar.set_sensitive(sensible)

    # --- Métodos de autorización ---

    def _mensaje(self, message_type, titulo, texto, parent=None):
        """Muestra un diálogo de mensaje (Adw.MessageDialog)."""
        parent = parent or self
        dialog = Adw.MessageDialog(
            transient_for=parent,
            modal=True,
            heading=titulo,
            body=texto,
        )
        dialog.add_response("close", traducir("Cerrar"))
        dialog.set_default_response("close")
        dialog.set_close_response("close")
        if message_type == Gtk.MessageType.ERROR:
            dialog.add_css_class("error")
        dialog.present()

    def _pregunta(self, titulo, texto, parent=None):
        """Muestra un diálogo de confirmación."""
        parent = parent or self
        dialog = Adw.MessageDialog(
            transient_for=parent,
            modal=True,
            heading=titulo,
            body=texto,
        )
        dialog.add_response("cancel", traducir("Cancelar"))
        dialog.add_response("ok", traducir("Continuar"))
        dialog.set_default_response("cancel")
        dialog.set_close_response("cancel")
        return dialog

    # --- Páginas (lazy loading) ---

    def _obtener_pagina(self, attr_name, page_class, *args):
        """Obtiene o crea una página (lazy loading)."""
        page = getattr(self, attr_name, None)
        if page is None:
            page = page_class(self, *args)
            setattr(self, attr_name, page)
        return page

    def mostrar_mantenimiento(self):
        page = self._obtener_pagina("maintenance_page", MaintenancePage)
        self.nav_view.push(page)

    def mostrar_software(self):
        page = self._obtener_pagina("software_page", SoftwarePage)
        self.nav_view.push(page)

    def mostrar_recomendadas(self):
        page = self._obtener_pagina("recommended_page", RecommendedPage)
        self.nav_view.push(page)

    def mostrar_backup(self):
        page = self._obtener_pagina("backup_page", BackupPage)
        self.nav_view.push(page)

    def mostrar_terminal(self):
        page = self._obtener_pagina("terminal_page", TerminalPage)
        self.nav_view.push(page)

    # --- Métodos de mantenimiento ---

    def _ejecutar_mantenimiento(self, pasos):
        """Ejecuta el flujo de mantenimiento."""
        if self.en_curso:
            return
        self.en_curso = True
        self._actualizar_sensibilidad()
        # ... lógica de mantenimiento

    def _abrir_diagnostico(self):
        """Abre el diálogo de diagnóstico."""
        dialog = DiagnosticsDialog(self)
        dialog.present()

    def _abrir_preferencias(self):
        """Abre el diálogo de preferencias."""
        dialog = PreferencesDialog(self)
        dialog.present()

    def _abrir_acerca_de(self):
        """Abre el diálogo acerca de."""
        dialog = AboutDialog(self)
        dialog.present()

    def _abrir_guia_integracion(self, parent=None):
        """Abre la guía de integración."""
        pass  # Implementar

    def _check_update(self, _btn=None):
        """Busca actualizaciones (GTK4 + helper)."""
        if self.comprobando_actualizacion:
            return
        self.comprobando_actualizacion = True
        self._actualizar_sensibilidad()
        self.status_label.set_text(traducir("Buscando actualizaciones…"))

        def check():
            try:
                fmt = formato_actualizacion()
                if fmt == "deb":
                    # Usar helper para respetar canal testing/stable
                    testing = self.preferencias.get("canal_actualizaciones") == "testing"
                    if testing:
                        cmd = comando_pkexec(HELPER_SISTEMA, "es", "--check-update-self-testing")
                    else:
                        cmd = comando_pkexec(HELPER_SISTEMA, "es", "--check-update-self")
                    salida = subprocess.run(cmd, capture_output=True, text=True, timeout=180,
                                            env={**os.environ, "LC_ALL": "C.UTF-8"}).stdout
                    GLib.idle_add(self._on_update_check_done, salida, None, testing)
                else:
                    release = obtener_release_actualizacion()
                    GLib.idle_add(self._on_update_check_done, release, None, False)
            except Exception as exc:
                GLib.idle_add(self._on_update_check_done, None, str(exc), False)

        threading.Thread(target=check, daemon=True).start()

    def _on_update_check_done(self, salida, error, testing=False):
        self.comprobando_actualizacion = False
        self._actualizar_sensibilidad()
        if error:
            self._write_log("[!] %s: %s" % (traducir("Error buscando actualizaciones"), error), "error")
            self.status_label.set_text(traducir("Error buscando actualizaciones"))
            return

        if salida is None:
            self.status_label.set_text(traducir("No se pudo comprobar actualizaciones"))
            return

        # Parsear el formato especial del helper: ##UPDATE:versión_instalada:versión_disponible
        # o ##NOUPDATE:versión_instalada:versión_disponible
        version_disponible = None
        version_instalada = version_app(para_apt=True)
        
        for linea in salida.splitlines():
            linea = linea.strip()
            if linea.startswith("##UPDATE:"):
                # Formato: ##UPDATE:versión_actual:versión_disponible
                partes = linea.split(":")
                if len(partes) >= 3:
                    version_disponible = partes[2]
                    version_instalada = partes[1]
                break
            elif linea.startswith("##NOUPDATE:"):
                # No hay actualización disponible
                version_disponible = None
                break

        if version_disponible and version_disponible not in ("(none)", "(ninguno)"):
            from aio_core.updates import version_numerica
            # Comparar versiones: si la disponible es mayor que la instalada, ofrecer actualización
            if version_numerica(version_disponible) > version_numerica(version_instalada):
                canal_texto = traducir("Testing") if testing else traducir("Estable")
                self._show_update_available_deb(version_disponible, canal_texto)
            else:
                self.status_label.set_text(traducir("Ya tienes la última versión"))
        else:
            self.status_label.set_text(traducir("Ya tienes la última versión"))

    def _show_update_available_deb(self, version, canal="Estable"):
        dialog = Adw.MessageDialog(
            transient_for=self,
            modal=True,
            heading=traducir("Actualización disponible"),
            body=traducir("Versión %s disponible en APT (%s). ¿Quieres abrir la página de descarga?") % (version, canal),
        )
        dialog.add_response("cancel", traducir("Cancelar"))
        dialog.add_response("ok", traducir("Abrir"))
        dialog.set_default_response("ok")
        dialog.connect("response", lambda d, r: self._on_update_dialog_response(d, r, version))
        dialog.present()

    def _on_update_dialog_response(self, dialog, response, version):
        if response == "ok":
            import webbrowser
            webbrowser.open(HOMEPAGE + "/releases/latest")

    # --- Métodos de utilidad ---

    def _write_log(self, texto, nivel="info"):
        """Escribe en el log."""
        pass

    def _contexto_programacion(self):
        """Contexto para el controlador de programación."""
        return {
            "traducir": traducir,
            "etiqueta": etiqueta,
            "pasos": PASOS,
            "formato": formato_actualizacion,
            "comando_host": comando_host,
            "comando_pkexec": comando_pkexec,
            "helper": helper_mantenimiento(),
        }

    # --- Handlers de botones ---

    def _on_menu_clicked(self, _button):
        """Handler del botón de menú."""
        self.menu_popover.popup()

    def _on_update_clicked(self, _button):
        """Handler del botón de actualizaciones."""
        self._check_update()

    def _on_maintenance_clicked(self, _button):
        """Handler del botón de mantenimiento."""
        self.mostrar_mantenimiento()

    def _on_software_clicked(self, _button):
        """Handler del botón de software."""
        self.mostrar_software()

    def _on_recommended_clicked(self, _button):
        """Handler del botón de apps recomendadas."""
        self.mostrar_recomendadas()

    def _on_backup_clicked(self, _button):
        """Handler del botón de backup."""
        self.mostrar_backup()

    def _on_terminal_clicked(self, _button):
        """Handler del botón de terminal."""
        self.mostrar_terminal()

    def _on_preferences_clicked(self, _button):
        """Handler del botón de preferencias."""
        self._abrir_preferencias()

    def _on_about_clicked(self, _button):
        """Handler del botón acerca de."""
        self._abrir_acerca_de()

    def _on_quit_clicked(self, _button):
        """Handler del botón salir."""
        self.close()

    # --- Compatibilidad legacy ---

    @property
    def programando(self):
        return getattr(self, '_programando', False)

    @programando.setter
    def programando(self, value):
        self._programando = value
        self._actualizar_sensibilidad()

    def _actualizar_sensibilidad(self):
        sensible = not (self.en_curso or getattr(self, '_programando', False) or self.comprobando_actualizacion)
        if hasattr(self, 'header_bar'):
            self.header_bar.set_sensitive(sensible)