"""Maintenance page for AIO Debian GUI (GTK4 + libadwaita)."""

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, GLib, Adw

from aio_core import (
    constants, Preferences as core_preferences,
    traduzir, comando_host, datos_distribucion_anfitrion, identidad_distribucion,
    notas_version, KERNEL, EDITOR, SHELL, MIRA, EDITOR_BASE, DEPARTAMENTOS, PREGUNTAS, ESTADOS_SISTEMA, HISTORIAL,
    es_flatpak, comando_host, leer_texto, paquete_instalado, version_app,
    distribucion_anfitrion, identidad_distribucion, logo_distribucion, imagen_logo_distribucion,
    NOTAS_VERSION, RECOMMENDED_ICON_DIR, BACKUP_ICON_DIR, TEMAS,
)

from aio_core import fastfetch
from ui.widgets.card import Card
from ui.widgets.queue_widget import QueueWidget


class MaintenancePage(Gtk.Box):
    """Página de mantenimiento (GTK4 + libadwaita)."""

    def __init__(self, window):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.window = window
        self.set_size_request(1000, 700)

        # ScrolledWindow que envuelve el grid principal
        self.scroller = Gtk.ScrolledWindow()
        self.scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.scroller.set_overlay_scrolling(False)
        self.append(self.scroller)

        # Contenedor principal con grid
        self.grid = Gtk.Grid()
        self.grid.set_property("margin", 12)
        self.grid.set_property("h_spacing", 12)
        self.grid.set_property("v_spacing", 12)
        self.scroller.set_child(self.grid)

        # Fila 1: Tarjetas principales
        # Columna 0-1: Información del sistema
        self.hardware_card = Card("Hardware", "computer")
        self.grid.attach(self.hardware_card, 0, 0, 1, 1)

        self.snap_card = Card("Snap", "snap")
        self.grid.attach(self.snap_card, 1, 0, 1, 1)

        # Columna 2: Espaciador
        spacer1 = Gtk.Box()
        self.grid.attach(spacer1, 2, 0, 1, 1)

        # Fila 2: Distribución + Kernel
        self.distro_card = Card("Distribución", "os")
        self.grid.attach(self.distro_card, 0, 1, 1, 1)

        self.kernel_card = Card("Kernel", "kernel")
        self.grid.attach(self.kernel_card, 1, 1, 1, 1)

        # Fila 3: Actualizaciones + Espaciador
        self.updates_card = Card("Actualizaciones", "system-software-update")
        self.grid.attach(self.updates_card, 0, 2, 1, 1)

        spacer2 = Gtk.Box()
        self.grid.attach(spacer2, 1, 2, 1, 1)

        # Botón de ejecutar mantenimiento al final
        self.btn_mantenimiento = Gtk.Button(label="Ejecutar mantenimiento")
        self.btn_mantenimiento.add_css_class("suggested-action")
        self.btn_mantenimiento.connect("clicked", self._ejecutar_mantenimiento)
        self.grid.attach(self.btn_mantenimiento, 0, 3, 3, 1)

        # Fila 4: Historial
        self.btn_historial = Gtk.Button(label="Historial de mantenimiento")
        self.btn_historial.connect("clicked", self._mostrar_historial)
        self.grid.attach(self.btn_historial, 0, 4, 3, 1)

        # Fila 5: Diagnóstico
        self.btn_diag = Gtk.Button(label="Ejecutar diagnóstico")
        self.btn_diag.connect("clicked", self._ejecutar_diag)
        self.grid.attach(self.btn_diag, 0, 5, 3, 1)

        # Inicializar datos
        GLib.idle_add(self._actualizar_datos_iniciales)

    def _actualizar_datos_iniciales(self):
        """Actualiza los datos de las tarjetas."""
        try:
            datos = fastfetch.get_system_info()
            if datos:
                # Hardware
                info = datos.get("hardware", {})
                modelo = info.get("model", "")
                if modelo:
                    for child in self.hardware_card.get_children():
                        if hasattr(child, 'get_children'):
                            for grandchild in child.get_children():
                                if isinstance(grandchild, Gtk.Label):
                                    grandchild.set_label(modelo)

                # Distribución
                distro = identidad_distribucion(datos.get("anfitrion", {})) if datos else ""
                if distro:
                    for child in self.distro_card.get_children():
                        if hasattr(child, 'get_children'):
                            for grandchild in child.get_children():
                                if isinstance(grandchild, Gtk.Label):
                                    grandchild.set_label(distro)

                # Kernel
                kernel = datos.get("kernel", "") if datos else ""
                if kernel:
                    for child in self.kernel_card.get_children():
                        if hasattr(child, 'get_children'):
                            for grandchild in child.get_children():
                                if isinstance(grandchild, Gtk.Label):
                                    grandchild.set_label(kernel)
        except Exception as e:
            print(f"Error updating maintenance page data: {e}")
        return False

    def actualizar_todas_las_tarjetas(self):
        """Actualiza todas las tarjetas (llamar desde el window)."""
        GLib.idle_add(self._actualizar_datos_iniciales)
        # Actualizar Snap
        try:
            import shutil
            snap_instalado = shutil.which("snap") is not None
            snap_lbl = Gtk.Label(label="Sí" if snap_instalado else "No")
            snap_lbl.add_css_class("dim-label")
            children = self.snap_card.get_children()
            if children and isinstance(children[0], Gtk.Box):
                for grandchild in children[0].get_children():
                    if isinstance(grandchild, Gtk.Label):
                        grandchild.set_label(snap_lbl.get_text())
        except Exception as e:
            print(f"Error actualizando snap card: {e}")

    def actualizar_tarjeta_actualizaciones(self):
        """Actualiza la tarjeta de actualizaciones."""
        GLib.idle_add(self._check_updates_lazy)

    def _check_updates_lazy(self):
        """Verifica actualizaciones de forma perezosa."""
        try:
            from aio_core import formato_actualizacion
            fmt = formato_actualizacion()
            self.updates_card.get_content_box().remove(self.updates_card.get_children()[0] if self.updates_card.get_children() else None)
            lbl = Gtk.Label(label="Verificar" if fmt == "deb" else "Versión disponible")
            lbl.add_css_class("dim-label")
            self.updates_card.get_content_box().append(lbl)
        except Exception as e:
            print(f"Error checking updates: {e}")
        return False

    def _ejecutar_mantenimiento(self, _btn):
        """Ejecuta el flujo de mantenimiento."""
        from aio_core import scheduler as core_scheduler
        # Aquí iría la lógica de mantenimiento
        self.window._show_update_available_deb("1.1.11", "Testing")

    def _mostrar_historial(self, _btn):
        """Muestra el diálogo de historial."""
        from .history_dialog import HistoryDialog
        dialog = HistoryDialog(self)
        dialog.present()

    def _ejecutar_diag(self, _btn):
        """Ejecuta diagnóstico."""
        from .diagnostics_dialog import DiagnosticsDialog
        dialog = DiagnosticsDialog(self)
        dialog.present()

    def limpiar(self):
        """Limpia la página."""
        for child in self.grid.get_children():
            self.grid.remove(child)
        # Recrear estructura básica
        self._setup_base()

    def _setup_base(self):
        """Recrear base de la página."""
        self.grid = Gtk.Grid()
        self.grid.set_property("margin", 12)
        self.grid.set_property("h_spacing", 12)
        self.grid.set_property("v_spacing", 12)
        self.scroller.set_child(self.grid)

        # Fila 1
        self.hardware_card = Card("Hardware", "computer")
        self.grid.attach(self.hardware_card, 0, 0, 1, 1)
        self.snap_card = Card("Snap", "snap")
        self.grid.attach(self.snap_card, 1, 0, 1, 1)
        spacer1 = Gtk.Box()
        self.grid.attach(spacer1, 2, 0, 1, 1)

        # Fila 2
        self.distro_card = Card("Distribución", "os")
        self.grid.attach(self.distro_card, 0, 1, 1, 1)
        self.kernel_card = Card("Kernel", "kernel")
        self.grid.attach(self.kernel_card, 1, 1, 1, 1)

        # Fila 3
        self.updates_card = Card("Actualizaciones", "system-software-update")
        self.grid.attach(self.updates_card, 0, 2, 1, 1)
        spacer2 = Gtk.Box()
        self.grid.attach(spacer2, 1, 2, 1, 1)

        # Fila 4: Botón mantenimiento
        self.btn_mantenimiento = Gtk.Button(label="Ejecutar mantenimiento")
        self.btn_mantenimiento.add_css_class("suggested-action")
        self.btn_mantenimiento.connect("clicked", self._ejecutar_mantenimiento)
        self.grid.attach(self.btn_mantenimiento, 0, 3, 3, 1)

        # Fila 5: Historial y Diagnóstico
        self.btn_historial = Gtk.Button(label="Historial de mantenimiento")
        self.btn_historial.connect("clicked", self._mostrar_historial)
        self.grid.attach(self.btn_historial, 0, 4, 3, 1)

        self.btn_diag = Gtk.Button(label="Ejecutar diagnóstico")
        self.btn_diag.connect("clicked", self._ejecutar_diag)
        self.grid.attach(self.btn_diag, 0, 5, 3, 1)

        GLib.idle_add(self._actualizar_datos_iniciales)