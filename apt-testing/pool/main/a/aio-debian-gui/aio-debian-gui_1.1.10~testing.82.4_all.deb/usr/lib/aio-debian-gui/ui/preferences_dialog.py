"""Preferences dialog for AIO Debian GUI (GTK4 + libadwaita)."""

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, Adw

from aio_core import traducir, PREFERENCIAS_DEFECTO, IDIOMAS, TEMAS


class PreferencesDialog(Adw.PreferencesWindow):
    """Diálogo de preferencias (GTK4 + libadwaita)."""

    def __init__(self, parent=None):
        super().__init__()
        self.set_title(traducir("Preferencias"))
        self.set_modal(True)
        self.set_transient_for(parent)
        self.set_default_size(400, -1)

        # Página de idioma
        page_lang = Adw.PreferencesPage()
        page_lang.set_title(traducir("Idioma"))

        lang_box = Gtk.Box(spacing=12)
        page_lang.add(lang_box)

        lang_lbl = Gtk.Label(label=traducir("Idioma"), xalign=0)
        lang_lbl.set_size_request(120, -1)
        lang_box.pack_start(lang_lbl, False, False, 0)

        self.lang_combo = Gtk.ComboBoxText()
        lang_names = {"es": "Español", "en": "English", "fr": "Français", "zh": "中文"}
        for code in sorted(IDIOMAS):
            self.lang_combo.append(code, lang_names.get(code, code))
        # Cargar preferencia actual
        current_lang = PREFERENCIAS_DEFECTO.get("idioma", "es")
        self.lang_combo.set_active_id(current_lang)
        lang_box.pack_start(self.lang_combo, True, True, 0)

        # Página de tema
        page_theme = Adw.PreferencesPage()
        page_theme.set_title(traducir("Tema"))

        theme_box = Gtk.Box(spacing=12)
        page_theme.add(theme_box)

        theme_lbl = Gtk.Label(label=traducir("Tema"), xalign=0)
        theme_lbl.set_size_request(120, -1)
        theme_box.pack_start(theme_lbl, False, False, 0)

        self.theme_combo = Gtk.ComboBoxText()
        theme_labels = {"sistema": traduzir("Sistema"), "claro": traduzir("Claro"), "oscuro": traduzir("Oscuro")}
        for code in sorted(TEMAS):
            self.theme_combo.append(code, theme_labels.get(code, code))
        current_theme = PREFERENCIAS_DEFECTO.get("tema", "sistema")
        self.theme_combo.set_active_id(current_theme)
        theme_box.pack_start(self.theme_combo, True, True, 0)

        # Página de interfaz simple
        page_simple = Adw.PreferencesPage()
        page_simple.set_title(traducir("Interfaz"))

        simple_box = Gtk.Box(spacing=12)
        page_simple.add(simple_box)

        simple_lbl = Gtk.Label(label=traducir("Interfaz simple"), xalign=0)
        simple_lbl.set_size_request(120, -1)
        simple_box.pack_start(simple_lbl, False, False, 0)

        self.simple_switch = Gtk.Switch()
        self.simple_switch.set_active(PREFERENCIAS_DEFECTO.get("modo_simple", False))
        simple_box.pack_start(self.simple_switch, False, False, 0)

        # Página de canal de actualizaciones
        page_channel = Adw.PreferencesPage()
        page_channel.set_title(traducir("Actualizaciones"))

        channel_box = Gtk.Box(spacing=12)
        page_channel.add(channel_box)

        channel_lbl = Gtk.Label(label=traducir("Canal de actualizaciones"), xalign=0)
        channel_lbl.set_size_request(120, -1)
        channel_box.pack_start(channel_lbl, False, False, 0)

        self.channel_combo = Gtk.ComboBoxText()
        self.channel_combo.append("stable", traduzir("Estable"))
        self.channel_combo.append("testing", traduzir("Testing"))
        current_channel = PREFERENCIAS_DEFECTO.get("canal_actualizaciones", "stable")
        self.channel_combo.set_active_id(current_channel)
        channel_box.pack_start(self.channel_combo, True, True, 0)

        # Página de carpeta repositorios
        page_repo = Adw.PreferencesPage()
        page_repo.set_title(traducir("Repositorios"))

        repo_box = Gtk.Box(spacing=12)
        page_repo.add(repo_box)

        repo_lbl = Gtk.Label(label=traducir("Carpeta repositorios"), xalign=0)
        repo_lbl.set_size_request(120, -1)
        repo_box.pack_start(repo_lbl, False, False, 0)

        self.repo_entry = Gtk.Entry()
        self.repo_entry.set_text(PREFERENCIAS_DEFECTO.get("carpeta_repositorios", ""))
        self.repo_entry.set_placeholder_text(traducir("Dejar vacío para usar la predeterminada"))
        repo_box.pack_start(self.repo_entry, True, True, 0)

        btn_browse = Gtk.Button(label=traducir("Examinar…"))
        btn_browse.connect("clicked", self._browse_repo_folder)
        repo_box.pack_start(btn_browse, False, False, 0)

        # Añadir todas las páginas
        self.add(page_lang)
        self.add(page_theme)
        self.add(page_simple)
        self.add(page_channel)
        self.add(page_repo)

    def _browse_repo_folder(self, _btn):
        dialog = Gtk.FileChooserDialog(title=traducir("Seleccionar carpeta"),
                                        transient_for=self, action=Gtk.FileChooserAction.SELECT_FOLDER)
        dialog.add_buttons(traducir("Cancelar"), Gtk.ResponseType.CANCEL,
                           traducir("Seleccionar"), Gtk.ResponseType.OK)
        if dialog.run() == Gtk.ResponseType.OK:
            self.repo_entry.set_text(dialog.get_filename())
        dialog.destroy()

    def get_preferences(self):
        return {
            "idioma": self.lang_combo.get_active_id() or "es",
            "tema": self.theme_combo.get_active_id() or "sistema",
            "modo_simple": self.simple_switch.get_active(),
            "canal_actualizaciones": self.channel_combo.get_active_id() or "stable",
            "carpeta_repositorios": self.repo_entry.get_text().strip(),
        }