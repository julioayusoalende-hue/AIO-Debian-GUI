"""Panel de salud del sistema (Health Dashboard) para AiO Debian GUI.

El diagnóstico se ejecuta dentro de la propia pestaña: una barra de progreso
muestra el avance, cada apartado pinta su semáforo (verde/naranja/rojo) y,
cuando algo requiere atención, la misma tarjeta ofrece el botón que lo
soluciona sin salir de la pestaña.
"""

import threading

import gi

gi.require_version('Gtk', '3.0')
from gi.repository import GLib, Gtk

from . import diagnostics as core_diagnostics

APP_ID_FLATPAK = "io.github.julioayusoalende_hue.aio_debian_gui"


# Mapeo de estado a color, texto e icono.
ESTADO_COLOR = {
    'ok': '#269343',        # verde
    'warning': '#E67E22',   # naranja
    'critical': '#C0392B',  # rojo
    'unknown': '#7F8C8D',   # gris
}

NOMBRE_ESTADO = {
    'ok': 'Correcto',
    'warning': 'Revisar',
    'critical': 'No superado',
    'unknown': 'Sin comprobar',
}

ESTADO_ICONO = {
    'ok': 'emblem-ok-symbolic',
    'warning': 'dialog-warning-symbolic',
    'critical': 'dialog-error-symbolic',
    'unknown': 'dialog-question-symbolic',
}

# Apartados que se muestran siempre, en este orden.
TARJETAS = [
    ("Espacio en /", "drive-harddisk-symbolic"),
    ("Estado de dpkg", "package-x-generic-symbolic"),
    ("Dependencias APT", "package-x-generic-symbolic"),
    ("Índices de APT", "view-refresh-symbolic"),
    ("Actualizaciones pendientes", "system-software-update-symbolic"),
    ("Reinicio pendiente", "system-reboot-symbolic"),
    ("Módulos DKMS", "preferences-system-symbolic"),
    ("Servicios systemd", "applications-system-symbolic"),
    ("Versión de AiO Debian GUI", "application-x-executable-symbolic"),
]


class HealthDashboard(Gtk.Box):
    """Dashboard visual de salud del sistema, con diagnóstico integrado."""

    def __init__(self, window, translate, passwordless):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=12, margin=12)
        self.window = window
        self.translate = translate
        self.passwordless = passwordless
        self.cards = {}  # name -> dict de widgets
        self.loading = False
        self.destroyed = False
        self.operation_token = None
        self.command_token = None
        self.resultados = []
        self.formato = self._formato_actualizacion()
        self.connect('destroy', self._on_destroy)

        # Cabecera: título y botón de ejecución.
        title_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        title = Gtk.Label(label=self.translate("Salud del sistema"))
        title.get_style_context().add_class("aio-heading")
        title.set_xalign(0)
        title_box.pack_start(title, True, True, 0)

        self.btn_actualizar_app = Gtk.Button(label=self.translate("Actualizar AiO"))
        self.btn_actualizar_app.get_style_context().add_class("suggested-action")
        self.btn_actualizar_app.set_tooltip_text(self.translate(
            "Buscar e instalar solo la actualización de AiO, sin ejecutar el mantenimiento del sistema"))
        self.btn_actualizar_app.connect("clicked", self._on_update_app)
        title_box.pack_end(self.btn_actualizar_app, False, False, 0)

        self.pack_start(title_box, False, False, 0)

        # Rejilla de tarjetas con desplazamiento.

        self.grid = Gtk.FlowBox(
            orientation=Gtk.Orientation.HORIZONTAL,
            column_spacing=12,
            row_spacing=12,
            selection_mode=Gtk.SelectionMode.NONE,
            min_children_per_line=3,
            max_children_per_line=3,
        )
        self.grid.set_valign(Gtk.Align.START)
        # Las tarjetas caben a tamaño normal; la barra de desplazamiento solo
        # aparece si el contenido (p. ej. con botones de solución) no cabe.
        scroller = Gtk.ScrolledWindow()
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroller.set_vexpand(True)
        scroller.add(self.grid)
        self.pack_start(scroller, True, True, 0)

        # Barra de progreso y resumen, abajo y sin abrir otra ventana.
        self.progress = Gtk.ProgressBar()
        self.progress.set_show_text(True)
        self.progress.set_text(self.translate("Listo para diagnosticar"))
        self.pack_start(self.progress, False, False, 0)

        self.status_label = Gtk.Label(xalign=0)
        self.status_label.set_line_wrap(True)
        self.status_label.get_style_context().add_class("dim-label")
        self.status_label.set_text(self.translate(
            "El diagnóstico se ejecuta automáticamente al abrir esta ventana."))
        self.pack_start(self.status_label, False, False, 0)

        self._build_initial_cards()
        self.show_all()

    # ------------------------------------------------------------------
    # Construcción de tarjetas
    # ------------------------------------------------------------------
    def _build_initial_cards(self):
        """Crea las tarjetas vacías con los nombres de las comprobaciones."""
        for name, icon_name in TARJETAS:
            self.cards[name] = self._create_card(name, icon_name)
            self.grid.add(self.cards[name]["frame"])

    def _create_card(self, name, icon_name):
        """Crea una tarjeta individual para una comprobación."""
        card_estado = {"status": "unknown"}
        frame = Gtk.Frame()
        frame.set_shadow_type(Gtk.ShadowType.NONE)
        frame.set_hexpand(True)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8, margin=12)
        box.set_halign(Gtk.Align.FILL)
        box.set_hexpand(True)

        # Icono + nombre.
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        icon = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.DIALOG)
        icon.set_pixel_size(28)
        header.pack_start(icon, False, False, 0)

        name_label = Gtk.Label(label=self.translate(name))
        name_label.get_style_context().add_class("aio-task-name")
        name_label.set_xalign(0)
        name_label.set_line_wrap(True)
        header.pack_start(name_label, True, True, 0)

        # Icono de estado en la esquina: verde, naranja, rojo o gris.
        status_icon = Gtk.Image.new_from_icon_name(
            ESTADO_ICONO["unknown"], Gtk.IconSize.BUTTON)
        header.pack_end(status_icon, False, False, 0)

        box.pack_start(header, False, False, 0)
        box.pack_start(Gtk.Separator(), False, False, 0)

        # Estado (círculo coloreado + texto CORRECTO/REVISAR/NO SUPERADO).
        status_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        status_circle = Gtk.DrawingArea()
        status_circle.set_size_request(16, 16)
        status_circle.connect("draw", self._draw_status_circle, card_estado)
        status_box.pack_start(status_circle, False, False, 0)

        status_label = Gtk.Label(label=self.translate(NOMBRE_ESTADO["unknown"]))
        status_label.set_xalign(0)
        status_label.get_style_context().add_class("aio-task-name")
        status_box.pack_start(status_label, True, True, 0)
        box.pack_start(status_box, False, False, 0)

        # Detalle.
        detail_label = Gtk.Label(label=self.translate("Sin comprobar"))
        detail_label.set_xalign(0)
        detail_label.set_line_wrap(True)
        detail_label.set_max_width_chars(40)
        detail_label.set_selectable(True)
        box.pack_start(detail_label, False, False, 0)

        # Consejo (oculto hasta que haga falta).
        advice_label = Gtk.Label(label="")
        advice_label.set_xalign(0)
        advice_label.set_line_wrap(True)
        advice_label.set_max_width_chars(40)
        advice_label.get_style_context().add_class("dim-label")
        advice_label.set_no_show_all(True)
        box.pack_start(advice_label, False, False, 0)

        # Botones de solución dentro de la propia tarjeta.
        actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        actions.set_no_show_all(True)
        box.pack_start(actions, False, False, 0)

        frame.add(box)

        return {
            "frame": frame,
            "box": box,
            "name_label": name_label,
            "status_icon": status_icon,
            "status_circle": status_circle,
            "estado": card_estado,
            "status_label": status_label,
            "detail_label": detail_label,
            "advice_label": advice_label,
            "actions": actions,
        }

    def _draw_status_circle(self, area, cr, estado):
        """Dibuja un círculo coloreado según el estado de su tarjeta."""
        status = estado["status"]
        color_hex = ESTADO_COLOR.get(status, ESTADO_COLOR["unknown"])
        r = int(color_hex[1:3], 16) / 255.0
        g = int(color_hex[3:5], 16) / 255.0
        b = int(color_hex[5:7], 16) / 255.0
        cr.set_source_rgba(r, g, b, 1.0)
        cr.arc(8, 8, 7, 0, 2 * 3.14159)
        cr.fill()

    # ------------------------------------------------------------------
    # Diagnóstico integrado en la pestaña
    # ------------------------------------------------------------------
    def _formato_actualizacion(self):
        try:
            from .constants import formato_actualizacion
            return formato_actualizacion()
        except Exception:
            return "desconocido"

    def _set_estado_tarjeta(self, name, status, detail="", advice=""):
        """Pinta una tarjeta con su semáforo y sus textos."""
        card = self.cards.get(name)
        if card is None:
            return
        card["status_label"].set_text(self.translate(NOMBRE_ESTADO.get(status, "Sin comprobar")))
        card["estado"]["status"] = status
        card["status_circle"].queue_draw()
        ctx = card["status_label"].get_style_context()
        for clase in ("status-ok", "status-warning", "status-critical", "status-unknown"):
            ctx.remove_class(clase)
        ctx.add_class(f"status-{status}")
        card["status_icon"].set_from_icon_name(
            ESTADO_ICONO.get(status, ESTADO_ICONO["unknown"]), Gtk.IconSize.BUTTON)
        card["detail_label"].set_text(detail or "—")
        if advice:
            card["advice_label"].set_text(advice)
            card["advice_label"].show()
        else:
            card["advice_label"].hide()

    def _limpiar_acciones(self, card):
        for widget in card["actions"].get_children():
            widget.destroy()
        card["actions"].hide()

    def _anadir_accion(self, card, etiqueta, callback, tooltip=None, comando=None):
        boton = Gtk.Button(label=self.translate(etiqueta))
        if tooltip:
            boton.set_tooltip_text(self.translate(tooltip))
        boton.get_style_context().add_class("suggested-action")
        boton.aio_command = comando
        boton.connect("clicked", callback)
        card["actions"].pack_start(boton, False, False, 0)
        card["actions"].show_all()

    def _pintar_resultado(self, resultado):
        """Pinta un resultado y añade el botón que lo soluciona."""
        name = resultado.get("name", "")
        status = resultado.get("status", "unknown")
        detail = self.translate(resultado.get("detail", ""))
        advice = resultado.get("advice", "")
        advice = self.translate(advice) if advice else ""
        if name not in self.cards:
            return
        self._set_estado_tarjeta(name, status, detail, advice)
        card = self.cards[name]
        self._limpiar_acciones(card)
        if status == "ok":
            return
        accion = resultado.get("action")
        if accion == "update":
            self._anadir_accion(card, "Actualizar AiO", self._on_update_app,
                                "Instalar la versión disponible con el actualizador de AiO")
        elif accion == "integration":
            self._anadir_accion(card, "Guía de integración", self._on_host_guide,
                                "Cómo conectar AiO con el sistema anfitrión")
        elif accion == "refresh-apt":
            self._anadir_accion(card, "Actualizar índices", self._on_refresh_apt,
                                "Refrescar los índices APT con autorización de administrador")
        elif accion == "maintenance":
            self._anadir_accion(card, "Abrir mantenimiento", self._on_open_maintenance,
                                "Ir a Configuración y mantenimiento")
        elif accion == "command":
            texto = resultado.get("command_label") or "Ver solución"
            self._anadir_accion(card, texto, self._on_solution,
                                resultado.get("command_tooltip"),
                                resultado.get("command"))

    def _progreso(self, fraccion, texto=None):
        if self.destroyed:
            return False
        self.progress.set_fraction(min(max(fraccion, 0.0), 1.0))
        if texto:
            self.progress.set_text(texto)
        return False

    def _on_destroy(self, _widget):
        self.destroyed = True
        self._liberar_operacion(self.operation_token)
        self._liberar_operacion(self.command_token)
        self.operation_token = None
        self.command_token = None

    def _iniciar_operacion(self, nombre):
        if self.destroyed or not hasattr(self.window, '_iniciar_operacion'):
            return None
        return self.window._iniciar_operacion(nombre)

    def _liberar_operacion(self, token):
        if token is not None and hasattr(self.window, '_finalizar_operacion'):
            self.window._finalizar_operacion(token)

    def _on_run_diagnostics(self, _boton=None, refresh_apt=False):
        if self.loading or self.destroyed:
            return
        self.operation_token = self._iniciar_operacion('Diagnóstico del sistema')
        if self.operation_token is None:
            self.status_label.set_text(self.translate('Espera a que termine la operación actual.'))
            return
        self.loading = True
        self.status_label.set_text(self.translate("Diagnóstico en curso…"))
        self._progreso(0.02, self.translate("Iniciando diagnóstico…"))
        for card in self.cards.values():
            self._limpiar_acciones(card)
            card["detail_label"].set_text(self.translate("Comprobando…"))

        formato = self.formato
        try:
            from .constants import version_app
            version_instalada = version_app(para_apt=True) if formato == "deb" else version_app()
        except Exception:
            version_instalada = "0"

        def worker():
            try:
                error_apt = None
                auditoria = None
                if refresh_apt and formato == "deb":
                    GLib.idle_add(self._progreso, 0.10,
                                  self.translate("Actualizando índices APT…"))
                    try:
                        error_apt, auditoria = core_diagnostics.refresh_apt_indices(
                            self.window.comando_refresco_diagnostico())
                    except Exception as exc:  # sin ayudante o sin autorización
                        error_apt = str(exc)

                GLib.idle_add(self._progreso, 0.45,
                              self.translate("Comprobando el sistema…"))
                resultados = (core_diagnostics.run_host_diagnostics(auditoria)
                              if formato == "flatpak"
                              else core_diagnostics.run_diagnostics(auditoria))

                if formato == "deb" and not refresh_apt:
                    for resultado in resultados:
                        if resultado.get("name") in ("Actualizaciones pendientes", "Índices de APT"):
                            detalle_actual = resultado.get("detail", "")
                            resultado["detail"] = (detalle_actual + " " if detalle_actual else "") + \
                                self.translate("Índices locales; no se actualizó APT.")

                if error_apt:
                    resultados.insert(0, {
                        "name": "Índices de APT", "status": "unknown",
                        "detail": "No se pudieron actualizar los índices APT; "
                                  "los resultados pueden estar desactualizados.",
                        "advice": error_apt,
                        "action": ("integration" if formato == "flatpak"
                                   else "refresh-apt"),
                    })
                    for resultado in resultados[1:]:
                        if resultado["name"] in ("Actualizaciones pendientes", "Índices de APT"):
                            resultado.update(
                                status="unknown",
                                detail="No se pudieron verificar con índices APT actualizados.",
                                advice="")

                GLib.idle_add(self._progreso, 0.80,
                              self.translate("Comprobando la versión de AiO…"))
                try:
                    # Se consulta el módulo vivo para que las pruebas puedan
                    # sustituirlo y para no cachear una respuesta antigua.
                    import importlib
                    core_updates = importlib.import_module("aio_core.updates")
                    estado_app = core_updates.estado_actualizacion_app(
                        formato, version_instalada, APP_ID_FLATPAK)
                except Exception as exc:
                    estado_app = {"status": "unknown", "detail": str(exc)}
                if formato == "deb" and (error_apt or not refresh_apt):
                    estado_app = {"status": "unknown",
                                  "detail": ("No se pudieron verificar las actualizaciones "
                                             "con índices APT actualizados." if error_apt else
                                             self.translate("No se actualizaron los índices APT; "
                                                            "la versión disponible puede estar desactualizada."))}
                estado = {"available": "warning", "current": "ok"}.get(
                    estado_app["status"], "unknown")
                resultados.append({
                    "name": "Versión de AiO Debian GUI",
                    "status": estado,
                    "detail": estado_app["detail"],
                    "advice": ("Hay una actualización disponible. Puedes instalarla desde aquí."
                               if estado_app["status"] == "available" else ""),
                    "action": "update" if estado_app["status"] == "available" else None,
                })
                self._marcar_acciones(resultados)
                GLib.idle_add(self._on_diagnostics_done, resultados, None)
            except Exception as exc:
                GLib.idle_add(self._on_diagnostics_done, None, str(exc))

        threading.Thread(target=worker, daemon=True).start()

    def _marcar_acciones(self, resultados):
        """Decide qué botón resuelve cada apartado que no está correcto."""
        for resultado in resultados:
            if resultado.get("action") or resultado.get("status") == "ok":
                continue
            name = resultado.get("name", "")
            advice = ((resultado.get("advice") or "") + " "
                      + (resultado.get("detail") or "")).lower()
            if name == "Espacio en /":
                resultado.update(action="command",
                                 command=("xdg-open", "trash:///"),
                                 command_label="Abrir la papelera",
                                 command_tooltip="Vacía archivos para liberar espacio")
            elif name == "Estado de dpkg":
                resultado.update(action="command",
                                 command=("pkexec", "dpkg", "--configure", "-a"),
                                 command_label="Completar paquetes",
                                 command_tooltip="Configura los paquetes a medias con dpkg")
            elif name == "Dependencias APT":
                resultado.update(action="command",
                                 command=("pkexec", "apt-get", "-f", "install"),
                                 command_label="Reparar dependencias",
                                 command_tooltip="Deja APT en un estado coherente")
            elif name in ("Actualizaciones pendientes", "Índices de APT"):
                resultado["action"] = "maintenance"
            elif name == "Reinicio pendiente":
                resultado.update(action="command",
                                 command=("gnome-session-quit", "--reboot", "--no-prompt"),
                                 command_label="Reiniciar ahora",
                                 command_tooltip="Guarda tu trabajo antes de reiniciar")
            elif name == "Módulos DKMS":
                resultado.update(action="command",
                                 command=("pkexec", "dkms", "autoinstall"),
                                 command_label="Recompilar módulos",
                                 command_tooltip="Reinstala los módulos DKMS registrados")
            elif name == "Servicios systemd":
                resultado.update(action="command",
                                 command=("systemctl", "--failed", "--no-pager"),
                                 command_label="Ver servicios fallidos",
                                 command_tooltip="Muestra las unidades que han fallado")
            elif "flatpak" in advice or "anfitrión" in advice or "host" in advice:
                resultado["action"] = "integration"
            else:
                resultado["action"] = "maintenance"

    def _on_diagnostics_done(self, results, error):
        self.loading = False
        self._liberar_operacion(self.operation_token)
        self.operation_token = None
        if self.destroyed:
            return GLib.SOURCE_REMOVE

        if error:
            self.progress.set_fraction(0.0)
            self.progress.set_text(self.translate("Diagnóstico interrumpido"))
            self.status_label.set_text(self.translate("Error: ") + error)
            return GLib.SOURCE_REMOVE

        self.resultados = results
        self.status_label.set_text("")
        GLib.idle_add(self._ofrecer_solucion, results)
        for resultado in results:
            self._pintar_resultado(resultado)

        recuento = {
            estado: sum(r.get("status") == estado for r in results)
            for estado in ("critical", "warning", "unknown", "ok")
        }
        total = len(results) or 1
        self.progress.set_fraction(recuento["ok"] / total)
        self.progress.set_text("%d/%d %s" % (recuento["ok"], len(results),
                                             self.translate("correctos")))
        estado = "Sin incidencias"
        if recuento["critical"] or recuento["warning"]:
            estado = "Requiere atención"
        elif recuento["unknown"]:
            estado = "No comprobado"
        self.status_label.set_text(
            "%s · %s: %s · %s: %s · %s: %s · %s: %s" % (
                self.translate(estado),
                self.translate("No superados"), recuento["critical"],
                self.translate("A revisar"), recuento["warning"],
                self.translate("Sin comprobar"), recuento["unknown"],
                self.translate("Correctos"), recuento["ok"]))
        return GLib.SOURCE_REMOVE

    # ------------------------------------------------------------------
    # Ventana de solución automática
    # ------------------------------------------------------------------
    PRIORIDAD = ("Estado de dpkg", "Dependencias APT", "Índices de APT",
                 "Actualizaciones pendientes", "Espacio en /", "Módulos DKMS",
                 "Reinicio pendiente", "Servicios systemd",
                 "Versión de AiO Debian GUI")

    def _elegir_problema(self, results):
        """Devuelve el problema más urgente que tiene una solución ofrecible."""
        problemas = [r for r in results
                     if r.get("status") in ("critical", "warning", "unknown")
                     and r.get("action") in ("command", "maintenance", "refresh-apt", "update")]
        if not problemas:
            return None
        orden = {n: i for i, n in enumerate(self.PRIORIDAD)}
        gravedad = {"critical": 0, "warning": 1, "unknown": 2}
        problemas.sort(key=lambda r: (gravedad[r["status"]], orden.get(r.get("name"), 99)))
        return problemas[0]

    def _ofrecer_solucion(self, results):
        """Abre una ventana con la solución del problema que bloquea el diagnóstico."""
        problema = self._elegir_problema(results)
        if problema is None or getattr(self, "dialogo_solucion", None) is not None:
            return GLib.SOURCE_REMOVE
        accion = problema["action"]
        if accion == "maintenance":
            boton_texto = "Ejecutar mantenimiento estándar"
            explicacion = ("Se ejecutará el mantenimiento estándar: actualiza el sistema, "
                           "limpia paquetes sobrantes y comprueba si hace falta reiniciar.")
        elif accion == "refresh-apt":
            boton_texto = "Reintentar actualización de índices"
            explicacion = "Se volverá a pedir autorización para actualizar los índices APT."
        elif accion == "update":
            boton_texto = "Actualizar AiO"
            explicacion = "Se abrirá el actualizador de AiO."
        else:
            boton_texto = problema.get("command_label") or "Ejecutar solución"
            explicacion = "Se ejecutará: " + " ".join(problema.get("command") or ())
        padre = self.get_toplevel()
        dialogo = Gtk.MessageDialog(
            transient_for=padre if isinstance(padre, Gtk.Window) else None,
            modal=True, message_type=Gtk.MessageType.WARNING,
            text=self.translate(problema.get("name", "")) + ": "
                 + self.translate(NOMBRE_ESTADO.get(problema["status"], "")))
        detalle = self.translate(problema.get("detail") or "")
        consejo = self.translate(problema.get("advice") or "")
        dialogo.format_secondary_text("\n\n".join(
            t for t in (detalle, consejo, self.translate(explicacion)) if t))
        dialogo.add_button(self.translate("Ahora no"), Gtk.ResponseType.CANCEL)
        dialogo.add_button(self.translate(boton_texto), Gtk.ResponseType.OK)
        dialogo.set_default_response(Gtk.ResponseType.CANCEL)
        self.dialogo_solucion = dialogo

        def respondido(d, respuesta):
            d.destroy()
            self.dialogo_solucion = None
            if respuesta == Gtk.ResponseType.OK:
                self._aplicar_solucion(problema)
        dialogo.connect("response", respondido)
        dialogo.show_all()
        return GLib.SOURCE_REMOVE

    def _aplicar_solucion(self, problema):
        accion = problema["action"]
        if accion == "maintenance":
            self._on_run_standard_maintenance()
        elif accion == "refresh-apt":
            self._on_refresh_apt(None)
        elif accion == "update":
            self._on_update_app(None)
        elif problema.get("command"):
            self._ejecutar_comando_confirmado(problema["command"])

    def _on_run_standard_maintenance(self):
        """Prepara el perfil estándar y lanza el mantenimiento desde la ventana principal."""
        ventana = getattr(self.window, "ventana_salud", None)
        if ventana is not None:
            ventana.hide()
        self.window.present()
        botones = getattr(self.window, "botones_preset", {})
        if "estandar" in botones:
            self.window._aplicar_preset(botones["estandar"], "estandar")
        self.window.notebook.set_current_page(0)
        self.window._iniciar(None)

    # ------------------------------------------------------------------
    # Acciones sin salir de la pestaña
    # ------------------------------------------------------------------
    def _on_update_app(self, _boton):
        if hasattr(self.window, "_buscar_actualizacion"):
            self.window._buscar_actualizacion(None)

    def _on_host_guide(self, _boton):
        if hasattr(self.window, "_abrir_guia_integracion"):
            self.window._abrir_guia_integracion(parent=self.window)

    def _on_open_maintenance(self, _boton):
        notebook = getattr(self.window, "notebook", None)
        if notebook is not None:
            notebook.set_current_page(0)
        ventana = getattr(self.window, "ventana_salud", None)
        if ventana is not None:
            ventana.hide()
            self.window.present()

    def _on_refresh_apt(self, _boton):
        dialogo = Gtk.MessageDialog(
            transient_for=self.get_toplevel(), modal=True,
            message_type=Gtk.MessageType.QUESTION,
            text=self.translate("¿Actualizar los índices APT?"),
        )
        dialogo.format_secondary_text(self.translate(
            "Se ejecutará apt update con autorización de administrador. No se instalarán paquetes."))
        dialogo.add_button(self.translate("Cancelar"), Gtk.ResponseType.CANCEL)
        dialogo.add_button(self.translate("Actualizar índices"), Gtk.ResponseType.OK)
        dialogo.set_default_response(Gtk.ResponseType.CANCEL)
        aceptado = dialogo.run() == Gtk.ResponseType.OK
        dialogo.destroy()
        if aceptado:
            self._on_run_diagnostics(refresh_apt=True)

    @staticmethod
    def _comando_destructivo(comando):
        return bool(comando) and (
            comando[0] == "gnome-session-quit"
            or (comando[0] == "pkexec" and len(comando) > 1
                and comando[1] in ("dpkg", "apt-get", "dkms"))
        )

    def _confirmar_comando_destructivo(self, comando):
        if comando and comando[0] == "gnome-session-quit":
            detalle = self.translate(
                "Se reiniciará el equipo y se cerrarán las aplicaciones. Guarda tu trabajo antes de continuar.")
        else:
            detalle = self.translate(
                "Esta acción puede modificar paquetes del sistema. Guarda tu trabajo y revisa la advertencia antes de continuar.")
        dialogo = Gtk.MessageDialog(
            transient_for=self.get_toplevel(), modal=True,
            message_type=Gtk.MessageType.WARNING,
            text=self.translate("Confirmar acción del sistema"),
        )
        dialogo.format_secondary_text(detalle + "\n\n" + " ".join(comando))
        dialogo.add_button(self.translate("Cancelar"), Gtk.ResponseType.CANCEL)
        dialogo.add_button(self.translate("Continuar"), Gtk.ResponseType.OK)
        dialogo.set_default_response(Gtk.ResponseType.CANCEL)
        aceptado = dialogo.run() == Gtk.ResponseType.OK
        dialogo.destroy()
        return aceptado

    def _ejecutar_comando_confirmado(self, comando):
        if self._comando_destructivo(comando) and not self._confirmar_comando_destructivo(comando):
            return
        self._ejecutar_comando(comando)

    def _on_solution(self, boton):
        comando = getattr(boton, "aio_command", None)
        if not comando:
            self._on_open_maintenance(boton)
            return
        self._ejecutar_comando_confirmado(comando)

    def _ejecutar_comando(self, comando):
        """Ejecuta una solución concreta y repite el diagnóstico al terminar."""
        import subprocess

        from .constants import comando_host

        self.command_token = self._iniciar_operacion('Solución de Salud del sistema')
        if self.command_token is None:
            self.status_label.set_text(self.translate('Espera a que termine la operación actual.'))
            return
        self.status_label.set_text(self.translate("Ejecutando: ") + " ".join(comando))
        self._progreso(0.5, self.translate("Aplicando la solución…"))

        def worker():
            try:
                resultado = subprocess.run(comando_host(*comando), capture_output=True,
                                           text=True, timeout=600, check=False)
                if resultado.returncode:
                    detalle = (resultado.stderr or resultado.stdout or "").strip()
                    raise RuntimeError(detalle or f"código de salida {resultado.returncode}")
                error = None
            except Exception as exc:
                error = str(exc)
            GLib.idle_add(self._comando_terminado, error)

        threading.Thread(target=worker, daemon=True).start()

    def _comando_terminado(self, error):
        self._liberar_operacion(self.command_token)
        self.command_token = None
        if self.destroyed:
            return GLib.SOURCE_REMOVE
        if error:
            self.status_label.set_text(self.translate("No se pudo ejecutar: ") + error)
            dialogo = Gtk.MessageDialog(
                transient_for=self.get_toplevel(), modal=True,
                message_type=Gtk.MessageType.ERROR,
                text=self.translate("No se pudo ejecutar la solución"),
            )
            dialogo.format_secondary_text(error)
            dialogo.add_button(self.translate("Cerrar"), Gtk.ResponseType.CLOSE)
            dialogo.run()
            dialogo.destroy()
            return GLib.SOURCE_REMOVE
        self._on_run_diagnostics()
        return GLib.SOURCE_REMOVE

    # ------------------------------------------------------------------
    def refresh(self):
        """Actualiza el panel con un diagnóstico nuevo, en la misma pestaña."""
        if self.loading:
            return
        self._on_run_diagnostics()

    def on_page_show(self):
        """Se llama cuando la pestaña se hace visible."""
        self.refresh()

    def on_page_hide(self):
        """Se llama cuando la pestaña se oculta."""
        pass


def create_health_dashboard(window, translate, passwordless):
    """Factory function para crear el dashboard."""
    return HealthDashboard(window, translate, passwordless)
