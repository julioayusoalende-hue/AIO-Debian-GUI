"""Asistente de bienvenida (Onboarding) para AyusOS.

Ventana a pantalla completa con flujo guiado paso a paso.
Se ejecuta automáticamente al primer arranque si es_ayusos() y no completado.
"""

import os
import subprocess
import sys
import threading
from http.client import HTTPException
from pathlib import Path
from urllib.request import urlopen

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from aio_core.constants import comando_host, traducir
from gi.repository import Gdk, GLib, GObject, Gtk

from ..branding import (
    color_acento_ayusos,
    es_ayusos,
    get_ayusos_codename,
    get_ayusos_version,
    icono_aplicacion,
    logo_cabecera,
    titulo_aplicacion,
)
from .ayusos_config import (
    AyusOSConfig,
    VALID_ACCENTS,
    VALID_KERNEL_VARIANTS,
    VALID_MAINTENANCE_SCHEDULES,
    VALID_NVIDIA_MODES,
    VALID_THEMES,
    get_effective_config,
    installed_gnome_tasks,
    load_user_preferences,
    mark_onboarding_done,
    save_user_preferences,
)
from .onboarding_nvidia import HELPER as NVIDIA_HELPER, REQUEST, RESULT, UPDATE_STEPS, steps_for_driver
BOOT_ID = Path("/proc/sys/kernel/random/boot_id")


# Estilo CSS para el onboarding
ONBOARDING_CSS = b"""
.onboarding-window {
    background-color: @theme_bg_color;
}
.onboarding-header {
    background: linear-gradient(to right, shade(@theme_bg_color, 0.9), @theme_bg_color);
    border-bottom: 1px solid alpha(@theme_fg_color, 0.12);
    padding: 24px 32px;
}
.onboarding-title {
    font-size: 1.8em;
    font-weight: 700;
    color: @theme_fg_color;
}
.onboarding-subtitle {
    font-size: 1.05em;
    color: alpha(@theme_fg_color, 0.7);
    margin-top: 4px;
}
.onboarding-progress {
    margin-top: 16px;
}
.onboarding-step-label {
    font-size: 0.9em;
    font-weight: 600;
    color: alpha(@theme_fg_color, 0.6);
}
.onboarding-content {
    padding: 32px 48px;
}
.onboarding-card {
    background-color: @theme_base_color;
    border: 1px solid alpha(@theme_fg_color, 0.1);
    border-radius: 16px;
    padding: 24px;
    margin-bottom: 16px;
}
.onboarding-card-title {
    font-size: 1.2em;
    font-weight: 700;
    margin-bottom: 8px;
}
.onboarding-card-desc {
    font-size: 0.95em;
    color: alpha(@theme_fg_color, 0.8);
}
.onboarding-button {
    font-weight: 600;
    padding: 12px 24px;
    border-radius: 8px;
    min-width: 140px;
}
.onboarding-button-primary {
    background-image: none;
    background-color: #279457;
    color: #ffffff;
    border-color: #279457;
}
.onboarding-button-secondary {
    background-color: alpha(@theme_fg_color, 0.08);
    color: @theme_fg_color;
}
.onboarding-button-accent {
    background-image: none;
    background-color: """ + color_acento_ayusos().encode() + b""";
    color: white;
}
.onboarding-footer {
    padding: 16px 32px;
    border-top: 1px solid alpha(@theme_fg_color, 0.1);
}
.onboarding-skip {
    color: alpha(@theme_fg_color, 0.5);
    font-size: 0.9em;
}
"""


def repositorio_accesible():
    """Comprueba que HTTPS alcanza un índice Debian real y no un portal cautivo."""
    try:
        with urlopen("https://deb.debian.org/debian/dists/stable/InRelease", timeout=4) as respuesta:
            return respuesta.readline(128).rstrip() == b"-----BEGIN PGP SIGNED MESSAGE-----"
    except (OSError, HTTPException):
        return False


class OnboardingStep:
    """Representa un paso del onboarding."""
    def __init__(self, step_id: str, title: str, description: str,
                 widget_factory, validate_fn=None, apply_fn=None):
        self.id = step_id
        self.title = title
        self.description = description
        self.widget_factory = widget_factory  # fn() -> Gtk.Widget
        self.validate_fn = validate_fn  # fn(widget) -> bool
        self.apply_fn = apply_fn  # fn(widget, config) -> bool
        self.widget = None
        self.completed = False


class OnboardingWizard(Gtk.Window):
    """Ventana principal del asistente de bienvenida."""

    __gsignals__ = {
        "completed": (GObject.SIGNAL_RUN_FIRST, None, ()),
        "cancelled": (GObject.SIGNAL_RUN_FIRST, None, ()),
    }

    def __init__(self, parent=None):
        super().__init__(title=titulo_aplicacion())
        self.set_icon_name(icono_aplicacion())
        self.set_default_size(900, 650)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_decorated(False)  # Pantalla completa sin decoraciones
        self.set_resizable(False)

        # CSS
        self._setup_css()

        # Estado
        self.steps: list[OnboardingStep] = []
        self.current_index = 0
        self.config = get_effective_config()
        self.version = get_ayusos_version() or "1.0"
        self.parent_window = parent
        self.conexion_disponible = False
        self.comprobando_conexion = False
        self.cerrado = False
        self.nvidia_outcome = None
        self.reboot_nvidia = False
        self.system_onboarding = os.environ.get("AYUSOS_ONBOARDING_SERVICE") == "1"

        # UI
        self._build_ui()
        self._define_steps()

        # Mostrar primer paso
        self._show_step(len(self.steps) - 1 if self.config.onboarding.initial_update else 0)

        self.connect("destroy", self._on_destroy)
        self.timer_conexion = GLib.timeout_add_seconds(7, self._comprobar_conexion)
        self._comprobar_conexion()
        if self.config.onboarding.initial_update not in ("", "running"):
            GLib.idle_add(self._continue_after_update)

    def _setup_css(self):
        provider = Gtk.CssProvider()
        provider.load_from_data(ONBOARDING_CSS)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(), provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
        self.get_style_context().add_class("onboarding-window")

    def _build_ui(self):
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.add(main_box)

        # Header
        self.header = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.header.get_style_context().add_class("onboarding-header")
        main_box.pack_start(self.header, False, False, 0)

        # Logo + título
        header_top = Gtk.Box(spacing=16)
        logo = logo_cabecera(64)
        if logo:
            header_top.pack_start(logo, False, False, 0)

        title_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self.title_label = Gtk.Label()
        self.title_label.get_style_context().add_class("onboarding-title")
        self.title_label.set_xalign(0)
        title_box.pack_start(self.title_label, False, False, 0)

        self.subtitle_label = Gtk.Label()
        self.subtitle_label.get_style_context().add_class("onboarding-subtitle")
        self.subtitle_label.set_xalign(0)
        title_box.pack_start(self.subtitle_label, False, False, 0)

        header_top.pack_start(title_box, True, True, 0)
        self.header.pack_start(header_top, False, False, 0)

        # Progress bar + step indicator
        progress_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.progress_bar = Gtk.LevelBar()
        self.progress_bar.set_mode(Gtk.LevelBarMode.CONTINUOUS)
        self.progress_bar.set_min_value(0)
        self.progress_bar.set_max_value(1)
        self.progress_bar.get_style_context().add_class("onboarding-progress")
        progress_box.pack_start(self.progress_bar, False, False, 0)

        self.step_label = Gtk.Label()
        self.step_label.get_style_context().add_class("onboarding-step-label")
        self.step_label.set_xalign(0)
        progress_box.pack_start(self.step_label, False, False, 0)

        self.header.pack_start(progress_box, False, False, 0)

        self.aviso_conexion = Gtk.InfoBar(message_type=Gtk.MessageType.INFO)
        red = Gtk.Box(spacing=8)
        self.estado_conexion = Gtk.Label(
            label=traducir("Comprobando la conexión a Internet…"), xalign=0, wrap=True)
        red.pack_start(self.estado_conexion, True, True, 0)
        red_ajustes = Gtk.Button(label=traducir("Ajustes de red"))
        red_ajustes.connect("clicked", self._abrir_ajustes_red)
        red.pack_start(red_ajustes, False, False, 0)
        self.btn_reintentar_conexion = Gtk.Button(label=traducir("Reintentar"))
        self.btn_reintentar_conexion.connect("clicked", self._comprobar_conexion)
        red.pack_start(self.btn_reintentar_conexion, False, False, 0)
        self.aviso_conexion.get_content_area().pack_start(red, True, True, 0)
        self.header.pack_start(self.aviso_conexion, False, False, 0)

        # Content area (scrollable)
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scrolled.get_style_context().add_class("onboarding-content")
        main_box.pack_start(scrolled, True, True, 0)

        self.content_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        self.content_box.set_border_width(32)
        scrolled.add(self.content_box)

        # Footer con botones
        self.footer = Gtk.Box(spacing=12)
        self.footer.get_style_context().add_class("onboarding-footer")
        self.footer.set_border_width(16)
        main_box.pack_start(self.footer, False, False, 0)

        # Botón saltar (izquierda)
        self.btn_skip = Gtk.Button(label=traducir("Saltar configuración"))
        self.btn_skip.get_style_context().add_class("onboarding-skip")
        self.btn_skip.connect("clicked", self._on_skip)
        self.footer.pack_start(self.btn_skip, False, False, 0)

        # Espaciador
        spacer = Gtk.Box()
        spacer.set_hexpand(True)
        self.footer.pack_start(spacer, True, True, 0)

        # Botón anterior
        self.btn_back = Gtk.Button(label=traducir("Anterior"))
        self.btn_back.get_style_context().add_class("onboarding-button")
        self.btn_back.get_style_context().add_class("onboarding-button-secondary")
        self.btn_back.connect("clicked", self._on_back)
        self.footer.pack_start(self.btn_back, False, False, 0)

        # Botón siguiente/finalizar
        self.btn_next = Gtk.Button(label=traducir("Siguiente"))
        self.btn_next.get_style_context().add_class("onboarding-button")
        self.btn_next.get_style_context().add_class("onboarding-button-primary")
        self.btn_next.connect("clicked", self._on_next)
        self.footer.pack_start(self.btn_next, False, False, 0)

    def _abrir_ajustes_red(self, _boton):
        try:
            subprocess.Popen(["gnome-control-center", "network"])
        except OSError:
            self._show_error(traducir("Abre los ajustes de red desde el menú del sistema."))

    def _comprobar_conexion(self, _boton=None):
        if self.comprobando_conexion:
            return GLib.SOURCE_CONTINUE
        self.comprobando_conexion = True
        self.btn_reintentar_conexion.set_sensitive(False)

        def consultar():
            GLib.idle_add(self._resultado_conexion, repositorio_accesible())

        threading.Thread(target=consultar, daemon=True).start()
        return GLib.SOURCE_CONTINUE

    def _resultado_conexion(self, disponible):
        if self.cerrado:
            return GLib.SOURCE_REMOVE
        self.conexion_disponible = disponible
        self.comprobando_conexion = False
        self.btn_reintentar_conexion.set_sensitive(True)
        self.aviso_conexion.set_message_type(
            Gtk.MessageType.INFO if disponible else Gtk.MessageType.WARNING
        )
        mensaje = ("Conexión a Internet comprobada." if disponible else
                   "Comprueba tu conexión a Internet. AyusOS necesita acceder al repositorio Debian para continuar.")
        self.estado_conexion.set_text(traducir(mensaje))
        self.btn_next.set_sensitive(disponible or self.config.onboarding.initial_update not in ("", "running"))
        self.btn_skip.set_sensitive(disponible and not self.config.onboarding.initial_update)
        return GLib.SOURCE_REMOVE

    def _define_steps(self):
        """Define la secuencia de pasos del onboarding."""
        self.steps = [
            OnboardingStep(
                "welcome",
                traducir("Bienvenido a AyusOS"),
                traducir("Configuraremos tu sistema en unos minutos. "
                         "Puedes personalizar cada opción o aceptar los valores recomendados."),
                self._create_welcome_step,
            ),
            OnboardingStep(
                "repos",
                traducir("Repositorios de software"),
                traducir("Habilita repositorios adicionales para acceder a más aplicaciones, "
                         "controladores y codecs."),
                self._create_repos_step,
                validate_fn=self._validate_repos,
                apply_fn=self._apply_repos,
            ),
            OnboardingStep(
                "flatpak",
                traducir("Flatpak y Flathub"),
                traducir("Instala aplicaciones sandbox desde Flathub, "
                         "la mayor tienda de apps Linux."),
                self._create_flatpak_step,
                validate_fn=self._validate_flatpak,
                apply_fn=self._apply_flatpak,
            ),
            OnboardingStep(
                "kernel",
                traducir("Variante de kernel"),
                traducir("Elige el kernel que mejor se adapte a tu hardware. "
                         "Backports = hardware nuevo, HWE = Ubuntu LTS."),
                self._create_kernel_step,
                validate_fn=self._validate_kernel,
                apply_fn=self._apply_kernel,
            ),
            OnboardingStep(
                "nvidia",
                traducir("Controladores NVIDIA"),
                traducir("Si tienes GPU NVIDIA, configura los controladores propietarios. "
                         "Detección automática recomendada."),
                self._create_nvidia_step,
                validate_fn=self._validate_nvidia,
                apply_fn=self._apply_nvidia,
            ),
            OnboardingStep(
                "gnome_ext",
                traducir("Extensiones de GNOME"),
                traducir("Mejora tu escritorio con extensiones populares: "
                         "dock, indicadores, efectos visuales..."),
                self._create_gnome_ext_step,
                validate_fn=self._validate_gnome_ext,
                apply_fn=self._apply_gnome_ext,
            ),
            OnboardingStep(
                "maintenance",
                traducir("Mantenimiento automático"),
                traducir("Programa actualizaciones y limpieza automáticas "
                         "para mantener tu sistema sano sin esfuerzo."),
                self._create_maintenance_step,
                validate_fn=self._validate_maintenance,
                apply_fn=self._apply_maintenance,
            ),
            OnboardingStep(
                "appearance",
                traducir("Apariencia"),
                traducir("Personaliza el tema, color de acento y fondos de pantalla."),
                self._create_appearance_step,
                validate_fn=self._validate_appearance,
                apply_fn=self._apply_appearance,
            ),
            OnboardingStep(
                "finish",
                traducir("¡Todo listo!"),
                traducir("Confirma tus elecciones para terminar la configuración."),
                self._create_finish_step,
            ),
        ]

    # --- Fábricas de widgets por paso ---

    def _create_welcome_step(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=24)
        box.get_style_context().add_class("onboarding-card")

        # Versión
        version_box = Gtk.Box(spacing=8)
        lbl_version = Gtk.Label(label=f"{traducir('Versión')}: {self.version}")
        lbl_version.get_style_context().add_class("onboarding-card-title")
        version_box.pack_start(lbl_version, False, False, 0)

        codename = get_ayusos_codename()
        lbl_codename = Gtk.Label(label=f"{traducir('Base')}: Debian {codename.capitalize()}")
        lbl_codename.get_style_context().add_class("onboarding-card-desc")
        version_box.pack_start(lbl_codename, False, False, 0)

        box.pack_start(version_box, False, False, 0)

        # Descripción
        desc = Gtk.Label()
        desc.set_markup(traducir(
            "<b>AyusOS Linux</b> es una distribución basada en Debian "
            "diseñada para ser completa, bonita y fácil de usar desde el primer momento.\n\n"
            "Este asistente configurará:\n"
            "• Repositorios y fuentes de software\n"
            "• Flatpak + Flathub para apps modernas\n"
            "• Kernel optimizado para tu hardware\n"
            "• Controladores gráficos (NVIDIA si aplica)\n"
            "• Extensiones de GNOME para productividad\n"
            "• Mantenimiento automático programado\n"
            "• Tema y personalización visual"
        ))
        desc.set_line_wrap(True)
        desc.set_xalign(0)
        desc.set_justify(Gtk.Justification.LEFT)
        box.pack_start(desc, False, False, 0)

        return box

    def _create_repos_step(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        box.get_style_context().add_class("onboarding-card")

        title = Gtk.Label(label=traducir("Repositorios de software"))
        title.get_style_context().add_class("onboarding-card-title")
        box.pack_start(title, False, False, 0)

        desc = Gtk.Label(label=traducir(
            "Debian separa el software en secciones. Habilitar 'contrib' y 'non-free' "
            "permite instalar controladores propietarios, firmware, codecs y apps como Steam."
        ))
        desc.set_line_wrap(True)
        desc.set_xalign(0)
        box.pack_start(desc, False, False, 0)

        # Checkboxes
        self.repo_contrib = Gtk.CheckButton(label=traducir("contrib / non-free (recomendado)"))
        self.repo_contrib.set_active(self.config.repos.contrib_nonfree)
        box.pack_start(self.repo_contrib, False, False, 0)

        self.repo_backports = Gtk.CheckButton(label=traducir("Debian Backports (kernel y apps nuevas)"))
        self.repo_backports.set_active(self.config.repos.backports)
        box.pack_start(self.repo_backports, False, False, 0)

        return box

    def _create_flatpak_step(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        box.get_style_context().add_class("onboarding-card")

        title = Gtk.Label(label=traducir("Flatpak y Flathub"))
        title.get_style_context().add_class("onboarding-card-title")
        box.pack_start(title, False, False, 0)

        desc = Gtk.Label(label=traducir(
            "Flatpak permite instalar aplicaciones en contenedores aislados, "
            "independientes de la versión de Debian. Flathub es la mayor tienda."
        ))
        desc.set_line_wrap(True)
        desc.set_xalign(0)
        box.pack_start(desc, False, False, 0)

        self.flatpak_enabled = Gtk.CheckButton(label=traducir("Habilitar Flatpak"))
        self.flatpak_enabled.set_active(self.config.flatpak.enabled)
        box.pack_start(self.flatpak_enabled, False, False, 0)

        self.flathub_enabled = Gtk.CheckButton(label=traducir("Añadir Flathub para todos los usuarios"))
        self.flathub_enabled.set_active(self.config.flatpak.flathub)
        self.flatpak_enabled.bind_property(
            "active", self.flathub_enabled, "sensitive", GObject.BindingFlags.SYNC_CREATE,
        )
        box.pack_start(self.flathub_enabled, False, False, 0)

        return box

    def _create_kernel_step(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        box.get_style_context().add_class("onboarding-card")

        title = Gtk.Label(label=traducir("Variante de kernel"))
        title.get_style_context().add_class("onboarding-card-title")
        box.pack_start(title, False, False, 0)

        desc = Gtk.Label(label=traducir(
            "• <b>Stable</b>: Kernel probado, máxima estabilidad (recomendado para servidores).\n"
            "• <b>Backports</b>: Instala un kernel más reciente y los controladores gráficos Mesa desde Debian Backports.\n"
            "• <b>HWE</b>: Hardware Enablement de Ubuntu (solo si base es Ubuntu LTS)."
        ))
        desc.set_line_wrap(True)
        desc.set_xalign(0)
        desc.set_use_markup(True)
        box.pack_start(desc, False, False, 0)

        self.kernel_combo = Gtk.ComboBoxText()
        for variant in ["stable", "backports", "hwe"]:
            label = {"stable": "Stable (recomendado)", "backports": "Backports", "hwe": "HWE (Ubuntu)"}[variant]
            self.kernel_combo.append(variant, traducir(label))
        self.kernel_combo.set_active(["stable", "backports", "hwe"].index(self.config.kernel.variant))
        box.pack_start(self.kernel_combo, False, False, 0)

        return box

    def _create_nvidia_step(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        box.get_style_context().add_class("onboarding-card")

        title = Gtk.Label(label=traducir("Controladores NVIDIA"))
        title.get_style_context().add_class("onboarding-card-title")
        box.pack_start(title, False, False, 0)

        desc = Gtk.Label(label=traducir(
            "Si tu equipo tiene GPU NVIDIA, los controladores propietarios ofrecen "
            "mejor rendimiento y compatibilidad (CUDA, juegos, renderizado).\n"
            "La detección automática analiza tu GPU, kernel, Secure Boot y portátiles híbridos. "
            "Al finalizar, verás el progreso y el resultado de la instalación."
        ))
        desc.set_line_wrap(True)
        desc.set_xalign(0)
        box.pack_start(desc, False, False, 0)

        self.nvidia_combo = Gtk.ComboBoxText()
        for mode in ["auto", "manual", "none"]:
            label = {"auto": "Auto-detectar (recomendado)", "manual": "Instalar al finalizar el asistente", "none": "No instalar"}[mode]
            self.nvidia_combo.append(mode, traducir(label))
        self.nvidia_combo.set_active(["auto", "manual", "none"].index(self.config.nvidia.mode))
        box.pack_start(self.nvidia_combo, False, False, 0)

        return box

    def _create_gnome_ext_step(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        box.get_style_context().add_class("onboarding-card")

        title = Gtk.Label(label=traducir("Extensiones de GNOME"))
        title.get_style_context().add_class("onboarding-card-title")
        box.pack_start(title, False, False, 0)

        desc = Gtk.Label(label=traducir(
            "Extensiones recomendadas para mejorar la productividad y experiencia visual."
        ))
        desc.set_line_wrap(True)
        desc.set_xalign(0)
        box.pack_start(desc, False, False, 0)

        self.ext_checks = {}
        extensions = [
            ("gnome-ext-appindicator", traducir("AppIndicator Support"),
             traducir("Iconos de bandeja para apps como Steam, Discord, VPN...")),
            ("gnome-ext-blur-shell", traducir("Blur my Shell"),
             traducir("Efecto de desenfoque translúcido en paneles y vistas.")),
            ("gnome-ext-dash-to-dock", traducir("Dash to Dock"),
             traducir("Convierte el dash en un dock configurable siempre visible.")),
            ("gnome-ext-caffeine", traducir("Caffeine"),
             traducir("Evita suspensión automática temporalmente.")),
            ("gnome-ext-tiling-shell", traducir("Tiling Shell"),
             traducir("Organiza ventanas en mosaico (estilo i3/sway).")),
        ]

        installed = installed_gnome_tasks()
        for ext_id, ext_name, ext_desc in extensions:
            if ext_id in installed:
                continue
            check = Gtk.CheckButton(label=ext_name)
            check.set_active(ext_id in self.config.gnome_extensions.enabled_by_default)
            check.set_tooltip_text(ext_desc)
            box.pack_start(check, False, False, 0)
            self.ext_checks[ext_id] = check
        if not self.ext_checks:
            desc.set_text(traducir("Las extensiones recomendadas ya están instaladas."))


        return box

    def _create_maintenance_step(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        box.get_style_context().add_class("onboarding-card")

        title = Gtk.Label(label=traducir("Mantenimiento automático"))
        title.get_style_context().add_class("onboarding-card-title")
        box.pack_start(title, False, False, 0)

        desc = Gtk.Label(label=traducir(
            "Programa tareas de mantenimiento (actualizaciones, limpieza, comprobaciones) "
            "para que se ejecuten automáticamente en segundo plano."
        ))
        desc.set_line_wrap(True)
        desc.set_xalign(0)
        box.pack_start(desc, False, False, 0)

        # Frecuencia
        freq_box = Gtk.Box(spacing=12)
        lbl_freq = Gtk.Label(label=traducir("Frecuencia:"))
        freq_box.pack_start(lbl_freq, False, False, 0)

        self.maint_freq = Gtk.ComboBoxText()
        for sched in ["daily", "weekly", "monthly", "disabled"]:
            label = {"daily": "Diario", "weekly": "Semanal", "monthly": "Mensual", "disabled": "Desactivado"}[sched]
            self.maint_freq.append(sched, traducir(label))
        self.maint_freq.set_active(["daily", "weekly", "monthly", "disabled"].index(self.config.maintenance.schedule))
        freq_box.pack_start(self.maint_freq, False, False, 0)
        box.pack_start(freq_box, False, False, 0)

        # Hora
        time_box = Gtk.Box(spacing=12)
        lbl_time = Gtk.Label(label=traducir("Hora:"))
        time_box.pack_start(lbl_time, False, False, 0)

        self.maint_time = Gtk.Entry()
        self.maint_time.set_text(self.config.maintenance.time)
        self.maint_time.set_width_chars(5)
        time_box.pack_start(self.maint_time, False, False, 0)
        box.pack_start(time_box, False, False, 0)

        # Tareas
        tasks_frame = Gtk.Frame(label=traducir("Tareas incluidas"))
        tasks_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        tasks_box.set_border_width(8)
        tasks_frame.add(tasks_box)

        self.maint_task_checks = {}
        tasks = [
            ("upgrade", traducir("Actualizar paquetes del sistema")),
            ("autoclean", traducir("Limpiar caché APT")),
            ("flatpak-update", traducir("Actualizar Flatpak")),
            ("snap-update", traducir("Actualizar Snap")),
            ("rebootcheck", traducir("Comprobar si requiere reinicio")),
        ]
        for task_id, task_name in tasks:
            check = Gtk.CheckButton(label=task_name)
            check.set_active(task_id in self.config.maintenance.tasks)
            tasks_box.pack_start(check, False, False, 0)
            self.maint_task_checks[task_id] = check

        box.pack_start(tasks_frame, False, False, 0)

        self.maint_notify = Gtk.CheckButton(label=traducir("Notificar antes de ejecutar"))
        self.maint_notify.set_active(self.config.maintenance.notify)
        box.pack_start(self.maint_notify, False, False, 0)

        return box

    def _create_appearance_step(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        box.get_style_context().add_class("onboarding-card")

        title = Gtk.Label(label=traducir("Apariencia"))
        title.get_style_context().add_class("onboarding-card-title")
        box.pack_start(title, False, False, 0)

        # Tema
        theme_box = Gtk.Box(spacing=12)
        lbl_theme = Gtk.Label(label=traducir("Tema:"))
        theme_box.pack_start(lbl_theme, False, False, 0)

        self.appearance_theme = Gtk.ComboBoxText()
        for theme in ["system", "light", "dark"]:
            label = {"system": "Sistema", "light": "Claro", "dark": "Oscuro"}[theme]
            self.appearance_theme.append(theme, traducir(label))
        self.appearance_theme.set_active(["system", "light", "dark"].index(self.config.appearance.theme))
        theme_box.pack_start(self.appearance_theme, False, False, 0)
        box.pack_start(theme_box, False, False, 0)

        # Acento
        accent_box = Gtk.Box(spacing=12)
        lbl_accent = Gtk.Label(label=traducir("Color de acento:"))
        accent_box.pack_start(lbl_accent, False, False, 0)

        self.appearance_accent = Gtk.ComboBoxText()
        accents = ["ayusos", "blue", "green", "orange", "purple", "red", "teal"]
        for acc in accents:
            self.appearance_accent.append(acc, traducir("AyusOS Rojo") if acc == "ayusos" else acc.capitalize())
        self.appearance_accent.set_active(accents.index(self.config.appearance.accent))
        accent_box.pack_start(self.appearance_accent, False, False, 0)
        box.pack_start(accent_box, False, False, 0)

        # Wallpaper
        wp_box = Gtk.Box(spacing=12)
        lbl_wp = Gtk.Label(label=traducir("Fondo de pantalla:"))
        wp_box.pack_start(lbl_wp, False, False, 0)

        self.appearance_wallpaper = Gtk.ComboBoxText()
        for mode in ["auto", "light", "dark", "custom"]:
            label = {"auto": "Automático (claro/oscuro)", "light": "Solo claro", "dark": "Solo oscuro", "custom": "Personalizado"}[mode]
            self.appearance_wallpaper.append(mode, traducir(label))
        self.appearance_wallpaper.set_active(["auto", "light", "dark", "custom"].index(self.config.appearance.wallpaper_mode))
        wp_box.pack_start(self.appearance_wallpaper, False, False, 0)
        box.pack_start(wp_box, False, False, 0)

        return box

    def _create_finish_step(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=24)
        box.get_style_context().add_class("onboarding-card")

        # Icono éxito
        icon = Gtk.Image.new_from_icon_name("emblem-ok-symbolic", Gtk.IconSize.DIALOG)
        icon.set_pixel_size(64)
        box.pack_start(icon, False, False, 0)

        title = Gtk.Label()
        title.set_markup(f"<big><b>{traducir('Actualización inicial de Debian')}</b></big>")
        box.pack_start(title, False, False, 0)

        desc = Gtk.Label(label=traducir(
            "AyusOS actualizará Debian antes de aplicar tus elecciones. "
            "Si hace falta reiniciar, el asistente retomará la configuración al volver a entrar."
        ))
        desc.set_line_wrap(True)
        desc.set_justify(Gtk.Justification.CENTER)
        box.pack_start(desc, False, False, 0)

        return box

    # --- Validación y aplicación por paso ---

    def _validate_repos(self, widget) -> bool:
        return True  # Siempre válido

    def _apply_repos(self, widget, config) -> bool:
        config.repos.contrib_nonfree = self.repo_contrib.get_active()
        config.repos.backports = self.repo_backports.get_active()
        return True

    def _validate_flatpak(self, widget) -> bool:
        return True

    def _apply_flatpak(self, widget, config) -> bool:
        config.flatpak.enabled = self.flatpak_enabled.get_active()
        config.flatpak.flathub = config.flatpak.enabled and self.flathub_enabled.get_active()
        return True

    def _validate_kernel(self, widget) -> bool:
        return self.kernel_combo.get_active_id() in VALID_KERNEL_VARIANTS

    def _apply_kernel(self, widget, config) -> bool:
        config.kernel.variant = self.kernel_combo.get_active_id() or "stable"
        return True

    def _validate_nvidia(self, widget) -> bool:
        return self.nvidia_combo.get_active_id() in VALID_NVIDIA_MODES

    def _apply_nvidia(self, widget, config) -> bool:
        config.nvidia.mode = self.nvidia_combo.get_active_id() or "auto"
        return True

    def _validate_gnome_ext(self, widget) -> bool:
        return True

    def _apply_gnome_ext(self, widget, config) -> bool:
        enabled = [ext_id for ext_id, check in self.ext_checks.items() if check.get_active()]
        config.gnome_extensions.enabled_by_default = enabled
        return True

    def _validate_maintenance(self, widget) -> bool:
        sched = self.maint_freq.get_active_id()
        if sched == "disabled":
            return True
        if sched not in VALID_MAINTENANCE_SCHEDULES or not any(
            check.get_active() for check in self.maint_task_checks.values()
        ):
            return False
        # Validar hora HH:MM
        import re
        time_str = self.maint_time.get_text().strip()
        return bool(re.match(r"^([01]?[0-9]|2[0-3]):[0-5][0-9]$", time_str))

    def _apply_maintenance(self, widget, config) -> bool:
        config.maintenance.schedule = self.maint_freq.get_active_id() or "weekly"
        config.maintenance.time = self.maint_time.get_text().strip() or "03:00"
        config.maintenance.tasks = [
            task_id for task_id, check in self.maint_task_checks.items()
            if check.get_active()
        ]
        config.maintenance.notify = self.maint_notify.get_active()
        return True

    def _validate_appearance(self, widget) -> bool:
        theme = self.appearance_theme.get_active_id()
        accent = self.appearance_accent.get_active_id()
        wallpaper = self.appearance_wallpaper.get_active_id()
        return (theme in VALID_THEMES and accent in VALID_ACCENTS and
                wallpaper in ["auto", "light", "dark", "custom"])

    def _apply_appearance(self, widget, config) -> bool:
        config.appearance.theme = self.appearance_theme.get_active_id() or "system"
        config.appearance.accent = self.appearance_accent.get_active_id() or "ayusos"
        config.appearance.wallpaper_mode = self.appearance_wallpaper.get_active_id() or "auto"
        return True

    def _install_nvidia(self):
        def finish(reboot, response):
            self.reboot_nvidia = reboot and response == Gtk.ResponseType.YES
            self.nvidia_outcome = True
            self._finish_onboarding()

        self._operation_dialog(
            "Instalación del controlador NVIDIA", "Preparando el controlador NVIDIA…",
            self._nvidia_worker, finish, deferred_reboot=self.system_onboarding,
        )

    def _operation_dialog(self, title, initial, worker, finish, *, deferred_reboot=False):
        dialog = Gtk.Dialog(
            title=traducir(title),
            transient_for=self, modal=True, deletable=False,
        )
        delete_handler = dialog.connect("delete-event", lambda *_: True)
        dialog.set_default_size(620, 330)
        content = dialog.get_content_area()
        content.set_spacing(10)
        content.set_border_width(12)
        status = Gtk.Label(label=traducir(initial))
        status.set_line_wrap(True)
        status.set_xalign(0)
        content.pack_start(status, False, False, 0)
        spinner = Gtk.Spinner()
        spinner.start()
        content.pack_start(spinner, False, False, 0)
        log = Gtk.TextView(editable=False, cursor_visible=False, monospace=True, wrap_mode=Gtk.WrapMode.WORD_CHAR)
        buffer = log.get_buffer()
        scroll = Gtk.ScrolledWindow()
        scroll.set_min_content_height(200)
        scroll.add(log)
        content.pack_start(scroll, True, True, 0)
        dialog.show_all()

        def append_line(line):
            buffer.insert(buffer.get_end_iter(), line + "\n")
            excess = buffer.get_line_count() - 250
            if excess > 0:
                buffer.delete(buffer.get_start_iter(), buffer.get_iter_at_line(excess))
            log.scroll_to_iter(buffer.get_end_iter(), 0, False, 0, 0)
            if line.startswith("[*] "):
                status.set_text(line[4:])

        def done(message, reboot):
            spinner.stop()
            spinner.hide()
            status.set_text(traducir(message))
            dialog.disconnect(delete_handler)
            dialog.set_deletable(True)
            if reboot:
                dialog.add_button(traducir("Más tarde"), Gtk.ResponseType.CLOSE)
                label = "Reiniciar al terminar la configuración" if deferred_reboot else "Reiniciar ahora"
                dialog.add_button(traducir(label), Gtk.ResponseType.YES)
            else:
                dialog.add_button(traducir("Continuar"), Gtk.ResponseType.CLOSE)
            dialog.set_default_response(Gtk.ResponseType.CLOSE)

            def respond(_dialog, response):
                dialog.destroy()
                finish(reboot, response)

            dialog.connect("response", respond)

        threading.Thread(
            target=worker,
            args=(lambda line: GLib.idle_add(append_line, line),
                  lambda message, reboot: GLib.idle_add(done, message, reboot)),
            daemon=True,
        ).start()

    def _nvidia_worker(self, log, complete):
        mode = self.config.nvidia.mode
        try:
            log("[*] Detectando el hardware NVIDIA…")
            report = subprocess.run(
                comando_host(NVIDIA_HELPER, "--nvidia-report"),
                stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=15,
            )
            flags = report.stdout.splitlines()
            if report.returncode or not any(flag.startswith("##NVIDIA:present:") for flag in flags):
                log((report.stderr or report.stdout).strip())
                complete("No se pudo verificar si hay una GPU NVIDIA compatible.", False)
                return
            if "##NVIDIA:present:0" in flags:
                message = ("No se detectó una GPU NVIDIA PCI. Se omitió la instalación automática del controlador."
                           if mode == "auto" else "No se pudo instalar NVIDIA porque no se detectó una GPU NVIDIA PCI.")
                complete(message, False)
                return
            if self.config.kernel.variant != "stable":
                complete("NVIDIA queda pendiente. Arranca primero con el kernel seleccionado y vuelve a ejecutar la instalación desde AiO.", False)
                return

            markers = set()
            error = ""

            def progress(line):
                nonlocal error
                line = line.rstrip()
                if line.startswith("##"):
                    markers.add(line)
                elif line:
                    log(line)
                    if line.startswith("[-] "):
                        error = line[4:]

            repos = self.config.repos.contrib_nonfree
            code = self._run_helper(f"driver:{int(repos)}", steps_for_driver(repos), log, progress)
        except (OSError, subprocess.SubprocessError) as exc:
            log(str(exc))
            complete("No se pudo ejecutar la instalación del controlador NVIDIA.", False)
            return

        if "##RESULT:nvidia-driver:0" in markers:
            reboot = "##REBOOT:1" in markers
            complete("Controlador NVIDIA preparado correctamente. Reinicia para aplicar los cambios." if reboot
                     else "El controlador NVIDIA ya estaba instalado y verificado para el kernel activo.", reboot)
        elif code in (126, 127):
            complete("No se autorizó la instalación del controlador NVIDIA.", False)
        elif error:
            complete(traducir("No se pudo instalar el controlador NVIDIA. %s") % error, False)
        else:
            complete(traducir("El asistente no confirmó la instalación de NVIDIA (código %d).") % code, False)

    def _run_helper(self, operation, steps, log, progress):
        if self.system_onboarding:
            print(f"{REQUEST}{operation}", flush=True)
            while line := sys.stdin.readline():
                if line.startswith(RESULT):
                    code = line[len(RESULT):].strip()
                    if code.isascii() and code.isdecimal():
                        return int(code)
                    break
                progress(line)
            raise OSError(traducir("El servicio de configuración se cerró sin informar del resultado."))

        log("[*] Esperando autorización de administrador…")
        with subprocess.Popen(
            comando_host("pkexec", NVIDIA_HELPER, "--lang", "es", *steps),
            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, errors="replace",
        ) as process:
            for line in process.stdout:
                progress(line)
            return process.wait()

    def _begin_initial_update(self):
        self.config.onboarding.initial_update = "running"
        if not self._save_checkpoint():
            return
        self._show_step(len(self.steps) - 1)

        def finish(reboot, response):
            if reboot:
                if response == Gtk.ResponseType.YES:
                    self._reboot_for_update()
            elif self.config.onboarding.initial_update == "ready":
                self._continue_after_update(offer_nvidia=False)

        self._operation_dialog(
            "Actualización inicial de Debian", "Preparando la actualización de Debian…",
            self._update_worker, finish,
        )

    def _update_worker(self, log, complete):
        markers = set()
        error = ""

        def progress(line):
            nonlocal error
            line = line.rstrip()
            if line.startswith("##"):
                markers.add(line)
            elif line:
                log(line)
                if line.startswith("[-] "):
                    error = line[4:]

        try:
            code = self._run_helper("update", UPDATE_STEPS, log, progress)
            if code or "##RESULT:onboarding-check-upgrade:0" not in markers:
                complete(error or traducir("No se pudo completar la actualización de Debian (código %d).") % code, False)
                return
            reboot = "##REBOOT:1" in markers
            checkpoint = "reboot:" + BOOT_ID.read_text().strip() if reboot else "ready"
        except (OSError, subprocess.SubprocessError) as exc:
            complete(str(exc), False)
            return

        def save_result():
            self.config.onboarding.initial_update = checkpoint
            if not self._save_checkpoint(show_error=False):
                self.config.onboarding.initial_update = "running"
                complete("No se pudo guardar el resultado. Pulsa Finalizar para volver a intentarlo.", False)
                return
            complete("Debian se actualizó. Reinicia para continuar con la configuración." if reboot
                     else "Debian se actualizó correctamente.", reboot)

        GLib.idle_add(save_result)

    def _save_checkpoint(self, *, show_error=True):
        prefs = load_user_preferences()
        self.config.onboarding.completed = False
        prefs.update(self.config.to_dict())
        prefs.pop("_schema_version", None)
        if save_user_preferences(prefs):
            return True
        if show_error:
            self._show_error(traducir("No se pudo guardar el progreso del asistente."))
        return False

    def _continue_after_update(self, *, offer_nvidia=True):
        checkpoint = self.config.onboarding.initial_update
        if checkpoint.startswith("reboot:"):
            try:
                same_boot = checkpoint == "reboot:" + BOOT_ID.read_text().strip()
            except OSError as exc:
                self._show_error(str(exc))
                return
            if same_boot:
                dialog = Gtk.MessageDialog(
                    transient_for=self, modal=True, message_type=Gtk.MessageType.INFO,
                    text=traducir("Reinicia para continuar la configuración"),
                )
                dialog.add_button(traducir("Más tarde"), Gtk.ResponseType.CLOSE)
                dialog.add_button(traducir("Reiniciar ahora"), Gtk.ResponseType.YES)
                dialog.set_default_response(Gtk.ResponseType.CLOSE)
                response = dialog.run()
                dialog.destroy()
                if response == Gtk.ResponseType.YES:
                    self._reboot_for_update()
                return

        if self.config.nvidia.mode == "none" or self.nvidia_outcome is not None:
            self._finish_onboarding()
        elif not offer_nvidia:
            self._install_nvidia()
        else:
            dialog = Gtk.MessageDialog(
                transient_for=self, modal=True, message_type=Gtk.MessageType.QUESTION,
                text=traducir("Instalación pendiente del controlador NVIDIA"),
            )
            dialog.format_secondary_text(traducir(
                "Debian está actualizado. Puedes instalar el controlador ahora o retomar este paso más tarde."
            ))
            dialog.add_button(traducir("Omitir NVIDIA"), Gtk.ResponseType.REJECT)
            dialog.add_button(traducir("Más tarde"), Gtk.ResponseType.CLOSE)
            dialog.add_button(traducir("Instalar NVIDIA"), Gtk.ResponseType.OK)
            dialog.set_default_response(Gtk.ResponseType.OK)
            response = dialog.run()
            dialog.destroy()
            if response == Gtk.ResponseType.OK:
                self._install_nvidia()
            elif response == Gtk.ResponseType.REJECT:
                self.config.nvidia.mode = "none"
                self._finish_onboarding()

    def _reboot_for_update(self):
        try:
            if self.system_onboarding:
                output = []
                code = self._run_helper("reboot", (), output.append, output.append)
                error = "".join(output).strip()
            else:
                result = subprocess.run(
                    comando_host("systemctl", "--no-block", "reboot"),
                    capture_output=True, text=True, timeout=15,
                )
                code, error = result.returncode, result.stderr.strip()
            if code:
                self._show_error(error or traducir("No se pudo reiniciar el sistema."))
        except (OSError, subprocess.SubprocessError) as exc:
            self._show_error(str(exc))

    def _finish_onboarding(self):
        self.config.nvidia.handled_by_wizard = True
        self.config.nvidia.reboot_boot_id = ""
        if self.reboot_nvidia and self.system_onboarding:
            try:
                self.config.nvidia.reboot_boot_id = BOOT_ID.read_text().strip()
            except OSError as exc:
                self._show_error(traducir("No se pudo programar el reinicio. %s") % exc)
        if not self._apply_finish(None, self.config):
            self._show_error(traducir("Error al guardar la configuración. Pulsa Finalizar para volver a intentarlo."))
            return
        if self.reboot_nvidia and not self.system_onboarding:
            try:
                result = subprocess.run(
                    comando_host("systemctl", "reboot"), capture_output=True, text=True, timeout=15,
                )
                if result.returncode:
                    self._show_error(result.stderr.strip() or traducir("No se pudo reiniciar el sistema."))
            except (OSError, subprocess.SubprocessError) as exc:
                self._show_error(str(exc))
        self.emit("completed")

    def _apply_finish(self, widget, config) -> bool:
        # Guardar todas las elecciones en preferencias de usuario (sin root).
        prefs = load_user_preferences()
        config.apps.auto_install = False
        prefs.update(config.to_dict())
        prefs["onboarding"].pop("initial_update", None)
        prefs.pop("_schema_version", None)
        return mark_onboarding_done(self.version, prefs)

    # --- Navegación ---

    def _show_step(self, index: int):
        if index < 0 or index >= len(self.steps):
            return

        self.current_index = index
        step = self.steps[index]

        # Limpiar contenido anterior
        for child in self.content_box.get_children():
            self.content_box.remove(child)

        # Crear widget del paso si no existe
        if step.widget is None:
            step.widget = step.widget_factory()

        # Añadir al contenido
        self.content_box.pack_start(step.widget, True, True, 0)
        self.content_box.show_all()

        # Actualizar header
        self.title_label.set_text(step.title)
        self.subtitle_label.set_text(step.description)
        self.progress_bar.set_value((index + 1) / len(self.steps))
        self.step_label.set_text(f"{traducir('Paso')} {index + 1} {traducir('de')} {len(self.steps)}: {step.title}")

        # Botones
        self.btn_back.set_sensitive(index > 0 and not self.config.onboarding.initial_update)
        self.btn_next.set_sensitive(self.conexion_disponible or self.config.onboarding.initial_update not in ("", "running"))
        self.btn_skip.set_sensitive(self.conexion_disponible and not self.config.onboarding.initial_update)
        is_last = (index == len(self.steps) - 1)
        self.btn_next.set_label(traducir("Finalizar") if is_last else traducir("Siguiente"))
        if is_last:
            self.btn_next.get_style_context().remove_class("onboarding-button-primary")
            self.btn_next.get_style_context().add_class("onboarding-button-accent")

    def _on_next(self, _):
        step = self.steps[self.current_index]
        if not self.conexion_disponible and self.config.onboarding.initial_update in ("", "running"):
            return

        # Validar
        if step.validate_fn and not step.validate_fn(step.widget):
            self._show_error(traducir("Por favor, completa correctamente este paso."))
            return

        if step.id == "finish":
            if self.config.onboarding.initial_update in ("", "running"):
                self._begin_initial_update()
            else:
                self._continue_after_update()
            return

        # Aplicar
        if step.apply_fn and not step.apply_fn(step.widget, self.config):
            self._show_error(traducir("Error al aplicar la configuración."))
            return

        step.completed = True

        self._show_step(self.current_index + 1)

    def _on_back(self, _):
        if self.current_index > 0 and not self.config.onboarding.initial_update:
            self._show_step(self.current_index - 1)

    def _on_skip(self, _):
        if not self.conexion_disponible or self.config.onboarding.initial_update:
            return
        dialog = Gtk.MessageDialog(
            transient_for=self,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=traducir("¿Saltar configuración?"),
        )
        dialog.format_secondary_text(traducir(
            "Se usarán los valores por defecto y se actualizará Debian. Podrás configurar todo después "
            "desde el Centro de Control."
        ))
        response = dialog.run()
        dialog.destroy()
        if response == Gtk.ResponseType.YES and self.conexion_disponible:
            self.config = AyusOSConfig()
            self.config.nvidia.mode = "none"
            self._begin_initial_update()

    def _show_error(self, message: str):
        dialog = Gtk.MessageDialog(
            transient_for=self,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=message,
        )
        dialog.run()
        dialog.destroy()

    def _on_destroy(self, _):
        self.cerrado = True
        GLib.source_remove(self.timer_conexion)
        if self.parent_window:
            self.parent_window.present()


def launch_onboarding(parent=None) -> OnboardingWizard:
    """Lanza el wizard de onboarding. Retorna la ventana."""
    wizard = OnboardingWizard(parent)
    wizard.show_all()
    return wizard


def should_launch_onboarding() -> bool:
    """True si se debe lanzar onboarding (AyusOS instalado + no completado)."""
    from .ayusos_config import is_onboarding_completed
    if not es_ayusos() or is_onboarding_completed():
        return False
    # Nunca interrumpir Calamares en la sesion Live.
    if os.path.exists("/run/live/medium"):
        return False
    try:
        if "boot=live" in Path("/proc/cmdline").read_text(encoding="utf-8").split():
            return False
    except OSError:
        pass
    return True
