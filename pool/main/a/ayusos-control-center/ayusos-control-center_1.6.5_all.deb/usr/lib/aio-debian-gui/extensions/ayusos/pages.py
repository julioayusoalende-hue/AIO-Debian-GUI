"""Pestañas y acciones del Centro de Control de AyusOS.

Este módulo se instala como extensión de aio-debian-gui; el core no conoce
nada de AyusOS. Los métodos se enlazan a la ventana principal en install().
"""

import os
import subprocess
import threading

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from aio_core.constants import (
    cabecera_mantenimiento,
    comando_host,
    etiqueta,
    tarjeta_mantenimiento,
    traducir,
)
from gi.repository import GdkPixbuf, GLib, Gtk

from .aio_core.ayusos_branding import ACENTOS
from .recovery import RECOVERY_HELPER, _parse_payload


class AyusOSPagesMixin:
    def _abrir_actualizacion_ayusos(self, _boton):
        dialogo = getattr(self, "ventana_actualizacion_ayusos", None)
        if dialogo is None:
            dialogo = Gtk.Dialog(title=traducir("Actualización AyusOS"), transient_for=self,
                                 modal=True, destroy_with_parent=True)
            dialogo.set_default_size(560, 480)
            dialogo.add_button(traducir("Cerrar"), Gtk.ResponseType.CLOSE)
            dialogo.connect("response", lambda ventana, _: ventana.hide())
            dialogo.connect("delete-event", lambda ventana, _: ventana.hide_on_delete())
            dialogo.get_content_area().pack_start(self._pagina_ayusos_update(), True, True, 0)
            self.ventana_actualizacion_ayusos = dialogo
        dialogo.show_all()
        dialogo.present()

    def _pagina_ayusos_update(self):
        """Contenido de la ventana de actualización de AyusOS."""
        pagina = self._pagina_tarjetas()
        contenido = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)

        # Tarjeta: Estado actual
        tarjeta, caja = tarjeta_mantenimiento(10)
        caja.pack_start(cabecera_mantenimiento("Estado de AyusOS", "system-software-update-symbolic"), False, False, 0)

        self.ayusos_update_status = self._etiqueta_estado()
        caja.pack_start(self.ayusos_update_status, False, False, 0)

        grid = Gtk.Grid(column_spacing=14, row_spacing=8)
        grid.set_border_width(4)
        caja.pack_start(grid, False, False, 0)

        self.ayusos_version_label = etiqueta("Versión actual: —")
        self.ayusos_channel_label = etiqueta("Canal: —")
        grid.attach(self.ayusos_version_label, 0, 0, 1, 1)
        grid.attach(self.ayusos_channel_label, 1, 0, 1, 1)

        self.ayusos_check_btn = Gtk.Button(label=traducir("Comprobar actualizaciones"))
        self.ayusos_check_btn.connect("clicked", self._ayusos_check_updates)
        caja.pack_start(self.ayusos_check_btn, False, False, 0)

        contenido.pack_start(tarjeta, False, False, 0)

        # Tarjeta: Actualizar
        tarjeta2, caja2 = tarjeta_mantenimiento(10)
        caja2.pack_start(cabecera_mantenimiento("Actualizar sistema", "system-software-update-symbolic"), False, False, 0)

        channel_box = Gtk.Box(spacing=8)
        channel_box.pack_start(etiqueta("Canal:"), False, False, 0)
        self.ayusos_channel_combo = Gtk.ComboBoxText()
        self.ayusos_channel_combo.append("stable", traducir("Estable (recomendado)"))
        self.ayusos_channel_combo.append("testing", traducir("Testing (próxima versión)"))
        self.ayusos_channel_combo.set_active_id("stable")
        self.ayusos_channel_combo.set_sensitive(False)
        self.ayusos_channel_combo.set_tooltip_text(traducir("Usa el canal configurado en el sistema."))
        channel_box.pack_start(self.ayusos_channel_combo, False, False, 0)
        caja2.pack_start(channel_box, False, False, 0)

        self.ayusos_dryrun_check = Gtk.CheckButton(label=traducir("Solo simular (dry-run)"))
        self.ayusos_dryrun_check.set_sensitive(False)
        self.ayusos_dryrun_check.set_tooltip_text(traducir("La simulación se realiza dentro del actualizador del sistema."))
        caja2.pack_start(self.ayusos_dryrun_check, False, False, 0)

        self.ayusos_update_btn = Gtk.Button(label=traducir("Actualizar ahora"))
        self.ayusos_update_btn.get_style_context().add_class("suggested-action")
        self.ayusos_update_btn.connect("clicked", self._ayusos_do_update)
        caja2.pack_start(self.ayusos_update_btn, False, False, 0)

        contenido.pack_start(tarjeta2, False, False, 0)

        # Tarjeta: Changelog
        tarjeta3, caja3 = tarjeta_mantenimiento(10)
        caja3.pack_start(cabecera_mantenimiento("Notas de versión", "text-x-changelog-symbolic"), False, False, 0)
        self.ayusos_changelog_view = Gtk.TextView(editable=False, cursor_visible=False, wrap_mode=Gtk.WrapMode.WORD_CHAR)
        self.ayusos_changelog_view.set_size_request(-1, 200)
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scrolled.add(self.ayusos_changelog_view)
        caja3.pack_start(scrolled, True, True, 0)
        contenido.pack_start(tarjeta3, True, True, 0)

        pagina.pack_start(self._scroll_tarjetas(contenido), True, True, 0)
        return pagina

    def _contenido_ayusos_snapshots(self):
        """Acciones de instantáneas dentro de la sección de Timeshift."""
        contenido = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)

        # Tarjeta: Estado
        tarjeta, caja = tarjeta_mantenimiento(10)
        caja.pack_start(cabecera_mantenimiento("Estado de snapshots", "drive-harddisk-symbolic"), False, False, 0)

        self.snapshots_status = self._etiqueta_estado()
        caja.pack_start(self.snapshots_status, False, False, 0)

        grid = Gtk.Grid(column_spacing=14, row_spacing=8)
        grid.set_border_width(4)
        caja.pack_start(grid, False, False, 0)

        self.snapshots_btrfs_label = etiqueta("Btrfs: —")
        self.snapshots_timeshift_label = etiqueta("Timeshift: —")
        self.snapshots_grub_label = etiqueta("grub-btrfs: —")
        grid.attach(self.snapshots_btrfs_label, 0, 0, 1, 1)
        grid.attach(self.snapshots_timeshift_label, 1, 0, 1, 1)
        grid.attach(self.snapshots_grub_label, 0, 1, 2, 1)

        btn_row = Gtk.Box(spacing=8)
        self.snapshots_refresh_btn = Gtk.Button(label=traducir("Actualizar estado"))
        self.snapshots_refresh_btn.connect("clicked", self._snapshots_refresh)
        btn_row.pack_start(self.snapshots_refresh_btn, False, False, 0)

        self.snapshots_grub_update_btn = Gtk.Button(label=traducir("Actualizar GRUB"))
        self.snapshots_grub_update_btn.connect("clicked", self._snapshots_grub_update)
        btn_row.pack_start(self.snapshots_grub_update_btn, False, False, 0)
        caja.pack_start(btn_row, False, False, 0)

        contenido.pack_start(tarjeta, False, False, 0)

        # Tarjeta: Crear snapshot
        tarjeta2, caja2 = tarjeta_mantenimiento(10)
        caja2.pack_start(cabecera_mantenimiento("Crear snapshot", "document-new-symbolic"), False, False, 0)

        comment_box = Gtk.Box(spacing=8)
        comment_box.pack_start(etiqueta("Comentario:"), False, False, 0)
        self.snapshots_comment = Gtk.Entry(placeholder_text=traducir("Ej: Antes de actualización"))
        self.snapshots_comment.set_max_length(512)
        comment_box.pack_start(self.snapshots_comment, True, True, 0)
        caja2.pack_start(comment_box, False, False, 0)

        tags_box = Gtk.Box(spacing=8)
        tags_box.pack_start(etiqueta("Tipo:"), False, False, 0)
        self.snapshots_tags = Gtk.ComboBoxText()
        for tag_id, tag_name in [("O", "Bajo demanda"), ("B", "Arranque"), ("H", "Horario"), ("D", "Diario"), ("W", "Semanal"), ("M", "Mensual")]:
            self.snapshots_tags.append(tag_id, traducir(tag_name))
        self.snapshots_tags.set_active_id("O")
        tags_box.pack_start(self.snapshots_tags, False, False, 0)
        caja2.pack_start(tags_box, False, False, 0)

        self.snapshots_create_btn = Gtk.Button(label=traducir("Crear snapshot ahora"))
        self.snapshots_create_btn.get_style_context().add_class("suggested-action")
        self.snapshots_create_btn.connect("clicked", self._snapshots_create)
        caja2.pack_start(self.snapshots_create_btn, False, False, 0)

        contenido.pack_start(tarjeta2, False, False, 0)

        # Tarjeta: Lista de snapshots
        tarjeta3, caja3 = tarjeta_mantenimiento(10)
        caja3.pack_start(cabecera_mantenimiento("Snapshots existentes", "view-list-symbolic"), False, False, 0)

        self.snapshots_list = Gtk.TreeView()
        self.snapshots_list.set_headers_visible(True)
        store = Gtk.ListStore(str, str, str, str, str)  # id, date, tags, comment, type
        self.snapshots_list.set_model(store)

        for i, title in enumerate(["ID", traducir("Fecha"), traducir("Tipo"), traducir("Comentario"), ""]):
            renderer = Gtk.CellRendererText()
            col = Gtk.TreeViewColumn(title, renderer, text=i)
            col.set_resizable(True)
            self.snapshots_list.append_column(col)

        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scrolled.set_size_request(-1, 250)
        scrolled.add(self.snapshots_list)
        caja3.pack_start(scrolled, True, True, 0)

        actions = Gtk.Box(spacing=8)
        self.snapshots_restore_btn = Gtk.Button(label=traducir("Restaurar seleccionado"))
        self.snapshots_restore_btn.connect("clicked", self._snapshots_restore)
        self.snapshots_delete_btn = Gtk.Button(label=traducir("Eliminar seleccionado"))
        self.snapshots_delete_btn.connect("clicked", self._snapshots_delete)
        actions.pack_start(self.snapshots_restore_btn, False, False, 0)
        actions.pack_end(self.snapshots_delete_btn, False, False, 0)
        caja3.pack_start(actions, False, False, 0)

        contenido.pack_start(tarjeta3, True, True, 0)

        return contenido

    def _pagina_ayusos_branding(self):
        """Pestaña: Apariencia (tema, acento, fondos, Plymouth)."""
        pagina = self._pagina_tarjetas()
        contenido = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)

        # Tarjeta: Tema y acento
        tarjeta, caja = tarjeta_mantenimiento(10)
        caja.pack_start(cabecera_mantenimiento("Tema y color de acento", "preferences-desktop-theme-symbolic"), False, False, 0)

        self.branding_status = self._etiqueta_estado()
        caja.pack_start(self.branding_status, False, False, 0)

        grid = Gtk.Grid(column_spacing=14, row_spacing=8)
        grid.set_border_width(4)
        caja.pack_start(grid, False, False, 0)

        # Tema
        grid.attach(etiqueta("Tema GTK:"), 0, 0, 1, 1)
        self.branding_theme = Gtk.ComboBoxText()
        for t in ["system", "light", "dark"]:
            self.branding_theme.append(t, traducir({"system": "Sistema", "light": "Claro", "dark": "Oscuro"}[t]))
        self.branding_theme.set_active_id("system")
        grid.attach(self.branding_theme, 1, 0, 1, 1)

        # Acento
        grid.attach(etiqueta("Color de acento:"), 0, 1, 1, 1)
        self.branding_accent = Gtk.ComboBoxText()
        for acc_id, acc_data in ACENTOS.items():
            self.branding_accent.append(acc_id, acc_data["name"])
        self.branding_accent.set_active_id("ayusos")
        grid.attach(self.branding_accent, 1, 1, 1, 1)

        btn_row = Gtk.Box(spacing=8)
        self.branding_apply_btn = Gtk.Button(label=traducir("Aplicar todo"))
        self.branding_apply_btn.get_style_context().add_class("suggested-action")
        self.branding_apply_btn.connect("clicked", self._branding_apply_all)
        btn_row.pack_start(self.branding_apply_btn, False, False, 0)

        self.branding_refresh_btn = Gtk.Button(label=traducir("Actualizar estado"))
        self.branding_refresh_btn.connect("clicked", self._branding_refresh)
        btn_row.pack_start(self.branding_refresh_btn, False, False, 0)
        grid.attach(btn_row, 0, 2, 2, 1)

        contenido.pack_start(tarjeta, False, False, 0)

        # Tarjeta: Fondos disponibles
        tarjeta2, caja2 = tarjeta_mantenimiento(10)
        caja2.pack_start(cabecera_mantenimiento("Fondos de pantalla", "preferences-desktop-wallpaper-symbolic"), False, False, 0)

        self.branding_wallpapers_grid = self._rejilla_tarjetas()
        caja2.pack_start(self._scroll_tarjetas(self.branding_wallpapers_grid), True, True, 0)
        contenido.pack_start(tarjeta2, True, True, 0)

        # Tarjeta: Plymouth
        tarjeta3, caja3 = tarjeta_mantenimiento(10)
        caja3.pack_start(cabecera_mantenimiento("Tema de arranque (Plymouth)", "system-reboot-symbolic"), False, False, 0)

        plymouth_box = Gtk.Box(spacing=8)
        plymouth_box.pack_start(etiqueta("Tema:"), False, False, 0)
        self.branding_plymouth = Gtk.ComboBoxText()
        from .aio_core.ayusos_branding import available_plymouth_themes

        themes = available_plymouth_themes()
        for theme in themes:
            self.branding_plymouth.append(theme, "AyusOS" if theme == "ayusos" else theme)
        if themes:
            self.branding_plymouth.set_active_id("ayusos" if "ayusos" in themes else themes[0])
        plymouth_box.pack_start(self.branding_plymouth, False, False, 0)

        self.branding_plymouth_btn = Gtk.Button(label=traducir("Aplicar tema"))
        self.branding_plymouth_btn.set_sensitive(bool(themes))
        self.branding_plymouth_btn.connect("clicked", self._branding_apply_plymouth)
        plymouth_box.pack_start(self.branding_plymouth_btn, False, False, 0)
        caja3.pack_start(plymouth_box, False, False, 0)

        contenido.pack_start(tarjeta3, False, False, 0)

        pagina.pack_start(self._scroll_tarjetas(contenido), True, True, 0)
        pagina.connect("map", self._branding_refresh)
        return pagina

    def _pagina_ayusos_autorizacion(self):
        """Pestaña: Autorización sin contraseña para administradores."""
        pagina = self._pagina_tarjetas()
        contenido = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)

        # Tarjeta: Estado actual
        tarjeta, caja = tarjeta_mantenimiento(10)
        caja.pack_start(cabecera_mantenimiento("Autorización AiO", "preferences-system-symbolic"), False, False, 0)

        self.autorizacion_status = self._etiqueta_estado()
        caja.pack_start(self.autorizacion_status, False, False, 0)

        grid = Gtk.Grid(column_spacing=14, row_spacing=8)
        grid.set_border_width(4)
        caja.pack_start(grid, False, False, 0)

        self.autorizacion_usuarios_label = etiqueta("Administradores autorizados: —")
        grid.attach(self.autorizacion_usuarios_label, 0, 0, 2, 1)

        btn_row = Gtk.Box(spacing=8)
        self.autorizacion_refresh_btn = Gtk.Button(label=traducir("Actualizar estado"))
        self.autorizacion_refresh_btn.connect("clicked", self._autorizacion_refresh)
        btn_row.pack_start(self.autorizacion_refresh_btn, False, False, 0)

        self.autorizacion_aplicar_btn = Gtk.Button(label=traducir("Aplicar a todos los administradores"))
        self.autorizacion_aplicar_btn.get_style_context().add_class("suggested-action")
        self.autorizacion_aplicar_btn.connect("clicked", self._autorizacion_aplicar)
        btn_row.pack_start(self.autorizacion_aplicar_btn, False, False, 0)
        grid.attach(btn_row, 0, 1, 2, 1)

        caja.pack_start(grid, False, False, 0)
        contenido.pack_start(tarjeta, False, False, 0)

        # Tarjeta: Usuarios actuales
        tarjeta2, caja2 = tarjeta_mantenimiento(10)
        caja2.pack_start(cabecera_mantenimiento("Usuarios con acceso sin contraseña", "system-users-symbolic"), False, False, 0)

        self.autorizacion_list = Gtk.TreeView()
        self.autorizacion_list.set_headers_visible(True)
        store = Gtk.ListStore(str, str, str)  # username, uid, status
        self.autorizacion_list.set_model(store)

        for i, title in enumerate([traducir("Usuario"), traducir("UID"), traducir("Estado")]):
            renderer = Gtk.CellRendererText()
            col = Gtk.TreeViewColumn(title, renderer, text=i)
            col.set_resizable(True)
            self.autorizacion_list.append_column(col)

        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scrolled.set_size_request(-1, 200)
        scrolled.add(self.autorizacion_list)
        caja2.pack_start(scrolled, True, True, 0)

        actions = Gtk.Box(spacing=8)
        self.autorizacion_remove_btn = Gtk.Button(label=traducir("Revocar acceso"))
        self.autorizacion_remove_btn.connect("clicked", self._autorizacion_revocar)
        actions.pack_end(self.autorizacion_remove_btn, False, False, 0)
        caja2.pack_start(actions, False, False, 0)

        contenido.pack_start(tarjeta2, True, True, 0)

        pagina.pack_start(self._scroll_tarjetas(contenido), True, True, 0)
        return pagina

    def _autorizacion_refresh(self, _boton):
        self.autorizacion_refresh_btn.set_sensitive(False)
        self.autorizacion_status.set_text(traducir("Cargando estado…"))

        def cargar():
            try:
                import subprocess
                result = subprocess.run(
                    ["/usr/local/libexec/ayusos-aio-autorizar", "status"],
                    capture_output=True, text=True, timeout=10
                )
                # El script imprime a stdout, no JSON. Parseamos.
                usuarios = []
                for line in result.stdout.strip().split('\n'):
                    if line.strip().startswith('- '):
                        # Formato: "  - user (UID 1000)"
                        parts = line.strip()[2:].split(' (UID ')
                        if len(parts) == 2:
                            usuarios.append((parts[0], parts[1].rstrip(')')))
                GLib.idle_add(self._autorizacion_refresh_done, True, usuarios)
            except (OSError, subprocess.SubprocessError) as exc:
                GLib.idle_add(self._autorizacion_refresh_done, False, str(exc))

        threading.Thread(target=cargar, daemon=True).start()

    def _autorizacion_refresh_done(self, ok, data):
        self.autorizacion_refresh_btn.set_sensitive(True)
        if not ok:
            self.autorizacion_status.set_text(traducir("Error: %s") % data)
            return GLib.SOURCE_REMOVE

        # Actualizar etiqueta resumen
        count = len(data)
        self.autorizacion_usuarios_label.set_text(traducir("Administradores autorizados: %d") % count)

        # Actualizar lista
        store = self.autorizacion_list.get_model()
        store.clear()
        for username, uid in data:
            store.append([username, uid, traducir("Activo")])

        self.autorizacion_status.set_text(traducir("Estado actualizado."))
        return GLib.SOURCE_REMOVE

    def _autorizacion_aplicar(self, _boton):
        self.autorizacion_aplicar_btn.set_sensitive(False)
        self.autorizacion_status.set_text(traducir("Aplicando autorización a todos los administradores…"))

        def aplicar():
            try:
                import subprocess
                result = subprocess.run(
                    ["/usr/local/libexec/ayusos-aio-autorizar", "apply"],
                    capture_output=True, text=True, timeout=30
                )
                if result.returncode == 0:
                    GLib.idle_add(self._autorizacion_aplicar_done, True, result.stdout)
                else:
                    GLib.idle_add(self._autorizacion_aplicar_done, False, result.stderr or result.stdout)
            except (OSError, subprocess.SubprocessError) as exc:
                GLib.idle_add(self._autorizacion_aplicar_done, False, str(exc))

        threading.Thread(target=aplicar, daemon=True).start()

    def _autorizacion_aplicar_done(self, ok, data):
        self.autorizacion_aplicar_btn.set_sensitive(True)
        if not ok:
            self.autorizacion_status.set_text(traducir("Error: %s") % data)
            return GLib.SOURCE_REMOVE

        self.autorizacion_status.set_text(traducir("Autorización aplicada correctamente."))
        self._autorizacion_refresh(None)
        return GLib.SOURCE_REMOVE

    def _autorizacion_revocar(self, _boton):
        selection = self.autorizacion_list.get_selection()
        model, treeiter = selection.get_selected()
        if not treeiter:
            return
        username = model[treeiter][0]

        # Confirmar
        dialog = Gtk.MessageDialog(
            transient_for=self.get_toplevel(),
            modal=True,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=traducir("¿Revocar el acceso sin contraseña para %s?") % username,
        )
        dialog.format_secondary_text(traducir("El usuario seguirá siendo administrador, pero necesitará contraseña para operaciones de AiO."))
        response = dialog.run()
        dialog.destroy()

        if response != Gtk.ResponseType.YES:
            return

        self.autorizacion_remove_btn.set_sensitive(False)
        self.autorizacion_status.set_text(traducir("Revocando acceso para %s…") % username)

        def revocar():
            try:
                import subprocess
                result = subprocess.run(
                    ["/usr/local/libexec/ayusos-aio-limpiar-usuario", username],
                    capture_output=True, text=True, timeout=10
                )
                if result.returncode == 0:
                    GLib.idle_add(self._autorizacion_revocar_done, True, username)
                else:
                    GLib.idle_add(self._autorizacion_revocar_done, False, result.stderr or result.stdout)
            except (OSError, subprocess.SubprocessError) as exc:
                GLib.idle_add(self._autorizacion_revocar_done, False, str(exc))

        threading.Thread(target=revocar, daemon=True).start()

    def _autorizacion_revocar_done(self, ok, data):
        self.autorizacion_remove_btn.set_sensitive(True)
        if not ok:
            self.autorizacion_status.set_text(traducir("Error: %s") % data)
            return GLib.SOURCE_REMOVE

        self.autorizacion_status.set_text(traducir("Acceso revocado para %s.") % data)
        self._autorizacion_refresh(None)
        return GLib.SOURCE_REMOVE

    def _ayusos_check_updates(self, _boton):
        self.ayusos_check_btn.set_sensitive(False)
        self.ayusos_update_status.set_text(traducir("Comprobando actualizaciones…"))

        def comprobar():
            try:
                import json

                from .aio_core import ayusos_update
                result = json.loads(ayusos_update.cli_check_updates())
            except (OSError, ValueError, RuntimeError, ImportError) as exc:
                GLib.idle_add(self._ayusos_check_done, False, str(exc))
            else:
                GLib.idle_add(self._ayusos_check_done, True, result)

        threading.Thread(target=comprobar, daemon=True).start()

    def _ayusos_check_done(self, ok, data):
        if self.destruida:
            return GLib.SOURCE_REMOVE
        self.ayusos_check_btn.set_sensitive(True)
        if not ok:
            self.ayusos_update_status.set_text(traducir("Error: %s") % data)
            return GLib.SOURCE_REMOVE

        if error := data.get("error"):
            self.ayusos_update_status.set_text(error)
            self.ayusos_update_btn.set_sensitive(False)
            self.ayusos_changelog_view.get_buffer().set_text("")
            return GLib.SOURCE_REMOVE

        update_available = data.get("update_available", False)
        current = data.get("current_version", "?")
        new_ver = data.get("new_version")
        channel = data.get("channel", "stable")

        self.ayusos_version_label.set_text(traducir("Versión actual: %s") % current)
        self.ayusos_channel_label.set_text(traducir("Canal: %s") % ("Testing" if channel == "testing" else "Estable"))

        if update_available and new_ver:
            self.ayusos_update_status.set_text(traducir("¡Actualización disponible: %s!") % new_ver)
            self.ayusos_update_btn.set_sensitive(True)
            # Cargar changelog
            try:
                from .aio_core import ayusos_update
                changelog = ayusos_update.get_changelog(new_ver)
                buffer = self.ayusos_changelog_view.get_buffer()
                buffer.set_text(changelog or traducir("Sin notas disponibles."))
            except Exception:
                pass
        else:
            self.ayusos_update_status.set_text(traducir("Sistema actualizado (versión %s).") % current)
            self.ayusos_update_btn.set_sensitive(False)
            buffer = self.ayusos_changelog_view.get_buffer()
            buffer.set_text(traducir("No hay actualizaciones pendientes."))

        return GLib.SOURCE_REMOVE

    def _ayusos_do_update(self, _boton):
        """Abre el actualizador del sistema dentro del Centro de Control."""
        try:
            subprocess.Popen([
                "gnome-terminal", "--title", traducir("Actualizar AyusOS"),
                "--", "/usr/lib/ayusos/actualizar-terminal",
            ])
        except OSError as exc:
            self.ayusos_update_status.set_text(traducir("No se pudo abrir el actualizador: %s") % exc)
            return
        self.ayusos_update_status.set_text(traducir(
            "Actualizador abierto. Sigue las instrucciones en la terminal."
        ))

    def _run_authorized_action(self, action, done, *args, operation="Snapshots de AyusOS"):
        token = self._iniciar_operacion(traducir(operation))
        if token is None:
            done(False, traducir("Hay otra operación en curso."))
            return

        def complete(ok, data):
            self._finalizar_operacion(token)
            return done(ok, data)

        def worker():
            try:
                result = subprocess.run(
                    comando_host("pkexec", RECOVERY_HELPER, action, *args),
                    capture_output=True, text=True, timeout=900,
                    stdin=subprocess.DEVNULL,
                )
                payload = _parse_payload(result.stdout)
                if not payload or result.returncode in (126, 127):
                    if result.returncode == 126:
                        raise RuntimeError(traducir("Autorización cancelada."))
                    raise RuntimeError(result.stderr.strip() or traducir("No se pudo autorizar la operación."))
                if result.returncode:
                    payload["success"] = False
            except (OSError, subprocess.SubprocessError, RuntimeError) as exc:
                GLib.idle_add(complete, False, str(exc))
            else:
                GLib.idle_add(complete, True, payload)

        threading.Thread(target=worker, daemon=True).start()

    def _snapshots_refresh(self, _boton):
        self.snapshots_refresh_btn.set_sensitive(False)
        self.snapshots_status.set_text(traducir("Esperando autorización para consultar snapshots…"))
        self._run_authorized_action("snapshot-status", self._snapshots_refresh_result)

    def _snapshots_refresh_result(self, ok, data):
        if ok:
            if data.get("success"):
                return self._snapshots_refresh_done(True, data["status"])
            data = data.get("message", "")
        return self._snapshots_refresh_done(False, data)

    def _snapshots_refresh_done(self, ok, data):
        self.snapshots_refresh_btn.set_sensitive(True)
        if not ok:
            self.snapshots_status.set_text(traducir("Error: %s") % data)
            return GLib.SOURCE_REMOVE

        btrfs = data.get("btrfs_root", False)
        timeshift = data.get("timeshift_installed", False)
        grub_btrfs = data.get("grub_btrfs_active", False)

        self.snapshots_btrfs_label.set_text(traducir("Btrfs: %s") % ("Sí" if btrfs else "No"))
        self.snapshots_timeshift_label.set_text(traducir("Timeshift: %s") % ("Sí" if timeshift else "No"))
        self.snapshots_grub_label.set_text(traducir("grub-btrfs: %s") % ("Activo" if grub_btrfs else "Inactivo"))

        # Cargar lista de snapshots
        store = self.snapshots_list.get_model()
        store.clear()
        for snap in data.get("timeshift_snapshots", [])[:50]:
            store.append([snap.get("id", ""), snap.get("date", ""), snap.get("tags", ""), snap.get("comment", ""), "timeshift"])
        for snap in data.get("btrfs_snapshots", [])[:50]:
            store.append([snap.get("id", ""), snap.get("path", ""), "", "", "btrfs"])

        self.snapshots_status.set_text(traducir("Estado actualizado."))
        return GLib.SOURCE_REMOVE

    def _snapshots_create(self, _boton):
        comment = self.snapshots_comment.get_text().strip() or "Snapshot AiO"
        tags = self.snapshots_tags.get_active_id() or "O"

        self.snapshots_create_btn.set_sensitive(False)
        self.snapshots_status.set_text(traducir("Creando snapshot…"))

        self._run_authorized_action("snapshot-create", self._snapshots_create_done, comment, tags)

    def _snapshots_create_done(self, ok, data):
        self.snapshots_create_btn.set_sensitive(True)
        if not ok:
            self.snapshots_status.set_text(traducir("Error: %s") % data)
            return GLib.SOURCE_REMOVE

        success = data.get("success", False)
        message = data.get("message", "")
        if success:
            self._snapshots_changed(data, traducir("Snapshot creado: %s") % message)
        else:
            self.snapshots_status.set_text(traducir("Error creando snapshot: %s") % message)
        return GLib.SOURCE_REMOVE

    def _snapshots_changed(self, data, message):
        if "status" in data:
            self._snapshots_refresh_done(True, data["status"])
        elif data.get("refresh_error"):
            message += "\n" + traducir("No se pudo actualizar la lista: %s") % data["refresh_error"]
        self.snapshots_status.set_text(message)

    def _snapshots_restore(self, _boton):
        selection = self.snapshots_list.get_selection()
        model, treeiter = selection.get_selected()
        if not treeiter:
            self._mensaje(Gtk.MessageType.INFO, traducir("Sin selección"), traducir("Selecciona un snapshot de la lista."))
            return

        if model.get_value(treeiter, 4) != "timeshift":
            self._mensaje(Gtk.MessageType.INFO, traducir("Snapshot de Timeshift"),
                          traducir("Selecciona un snapshot de Timeshift para esta operación."))
            return
        snap_id = model.get_value(treeiter, 0)
        if not snap_id:
            return

        dialog = Gtk.MessageDialog(
            transient_for=self, message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.YES_NO, text=traducir("¿Restaurar snapshot %s?") % snap_id
        )
        dialog.format_secondary_text(traducir(
            "Esto revertirá el sistema al estado del snapshot. Requerirá reinicio."
        ))
        response = dialog.run()
        dialog.destroy()

        if response != Gtk.ResponseType.YES:
            return

        self.snapshots_restore_btn.set_sensitive(False)
        self.snapshots_status.set_text(traducir("Restaurando snapshot…"))

        self._run_authorized_action("restore", self._snapshots_restore_done, snap_id)

    def _snapshots_restore_done(self, ok, data):
        self.snapshots_restore_btn.set_sensitive(True)
        if not ok:
            self.snapshots_status.set_text(traducir("Error: %s") % data)
            return GLib.SOURCE_REMOVE

        success = data.get("success", False)
        message = data.get("message", "")
        if success:
            self.snapshots_status.set_text(traducir("Snapshot restaurado. Reinicia para aplicar: %s") % message)
        else:
            self.snapshots_status.set_text(traducir("Error restaurando: %s") % message)
        return GLib.SOURCE_REMOVE

    def _snapshots_delete(self, _boton):
        selection = self.snapshots_list.get_selection()
        model, treeiter = selection.get_selected()
        if not treeiter:
            self._mensaje(Gtk.MessageType.INFO, traducir("Sin selección"), traducir("Selecciona un snapshot de la lista."))
            return

        if model.get_value(treeiter, 4) != "timeshift":
            self._mensaje(Gtk.MessageType.INFO, traducir("Snapshot de Timeshift"),
                          traducir("Selecciona un snapshot de Timeshift para esta operación."))
            return
        snap_id = model.get_value(treeiter, 0)
        if not snap_id:
            return

        dialog = Gtk.MessageDialog(
            transient_for=self, message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.YES_NO, text=traducir("¿Eliminar snapshot %s?") % snap_id
        )
        dialog.format_secondary_text(traducir("Esta acción no se puede deshacer."))
        response = dialog.run()
        dialog.destroy()

        if response != Gtk.ResponseType.YES:
            return

        self.snapshots_delete_btn.set_sensitive(False)
        self.snapshots_status.set_text(traducir("Eliminando snapshot…"))

        self._run_authorized_action("snapshot-delete", self._snapshots_delete_done, snap_id)

    def _snapshots_delete_done(self, ok, data):
        self.snapshots_delete_btn.set_sensitive(True)
        if not ok:
            self.snapshots_status.set_text(traducir("Error: %s") % data)
            return GLib.SOURCE_REMOVE

        success = data.get("success", False)
        message = data.get("message", "")
        if success:
            self._snapshots_changed(data, traducir("Snapshot eliminado: %s") % message)
        else:
            self.snapshots_status.set_text(traducir("Error eliminando: %s") % message)
        return GLib.SOURCE_REMOVE

    def _snapshots_grub_update(self, _boton):
        self.snapshots_grub_update_btn.set_sensitive(False)
        self.snapshots_status.set_text(traducir("Actualizando menú GRUB…"))

        self._run_authorized_action("grub", self._snapshots_grub_done)

    def _snapshots_grub_done(self, ok, data):
        self.snapshots_grub_update_btn.set_sensitive(True)
        if not ok:
            self.snapshots_status.set_text(traducir("Error: %s") % data)
            return GLib.SOURCE_REMOVE

        success = data.get("success", False)
        message = data.get("message", "")
        self.snapshots_status.set_text(traducir("GRUB actualizado: %s") % message if success else traducir("Error: %s") % message)
        return GLib.SOURCE_REMOVE

    def _branding_refresh(self, _widget):
        if not self.branding_refresh_btn.get_sensitive():
            return
        self.branding_refresh_btn.set_sensitive(False)
        self.branding_status.set_text(traducir("Cargando estado…"))

        def cargar():
            try:
                import json

                from .aio_core import ayusos_branding
                result = json.loads(ayusos_branding.cli_branding_status())
            except (OSError, ValueError, RuntimeError, ImportError) as exc:
                GLib.idle_add(self._branding_refresh_done, False, str(exc))
            else:
                GLib.idle_add(self._branding_refresh_done, True, result)

        threading.Thread(target=cargar, daemon=True).start()

    def _branding_refresh_done(self, ok, data):
        self.branding_refresh_btn.set_sensitive(True)
        if not ok:
            self.branding_status.set_text(traducir("Error: %s") % data)
            return GLib.SOURCE_REMOVE

        self.branding_theme.set_active_id(data.get("theme", "system"))
        self.branding_accent.set_active_id(data.get("accent", "ayusos"))
        if theme := data.get("plymouth_theme"):
            self.branding_plymouth.set_active_id(theme)

        # Cargar wallpapers
        grid = self.branding_wallpapers_grid
        for child in grid.get_children():
            grid.remove(child)
        for wp in data.get("available_wallpapers", []):
            grid.add(self._crear_tarjeta_wallpaper(wp))
        grid.show_all()

        self.branding_status.set_text(traducir("Estado actualizado."))
        return GLib.SOURCE_REMOVE

    def _branding_set_wallpaper(self, _boton, path):
        self.branding_status.set_text(traducir("Aplicando fondo…"))
        def aplicar():
            try:
                import json

                from .aio_core import ayusos_branding
                result = json.loads(ayusos_branding.cli_set_wallpaper(path, "both"))
            except (OSError, ValueError, RuntimeError, ImportError) as exc:
                GLib.idle_add(self._branding_wallpaper_done, False, str(exc))
            else:
                GLib.idle_add(self._branding_wallpaper_done, True, result)
        threading.Thread(target=aplicar, daemon=True).start()

    def _branding_wallpaper_done(self, ok, data):
        if not ok:
            self.branding_status.set_text(traducir("Error: %s") % data)
        elif data.get("success"):
            self.branding_status.set_text(traducir("Fondo aplicado correctamente."))
        else:
            self.branding_status.set_text(traducir("No se pudo aplicar el fondo."))
        return GLib.SOURCE_REMOVE

    def _branding_apply_all(self, _boton):
        self.branding_apply_btn.set_sensitive(False)
        self.branding_status.set_text(traducir("Aplicando tema, acento y fondos…"))

        theme = self.branding_theme.get_active_id() or "system"
        accent = self.branding_accent.get_active_id() or "ayusos"

        def aplicar():
            try:
                import json

                from .aio_core import ayusos_branding
                result = json.loads(ayusos_branding.cli_apply_all(theme, accent))
            except (OSError, ValueError, RuntimeError, ImportError) as exc:
                GLib.idle_add(self._branding_apply_done, False, str(exc))
            else:
                GLib.idle_add(self._branding_apply_done, True, result)

        threading.Thread(target=aplicar, daemon=True).start()

    def _branding_apply_done(self, ok, data):
        self.branding_apply_btn.set_sensitive(True)
        if not ok:
            self.branding_status.set_text(traducir("Error: %s") % data)
        else:
            success = data.get("success", False)
            self.branding_status.set_text(traducir("Branding aplicado correctamente.") if success else traducir("Error aplicando branding."))
        return GLib.SOURCE_REMOVE

    def _branding_apply_plymouth(self, _boton):
        theme = self.branding_plymouth.get_active_id() or "ayusos"
        self.branding_plymouth_btn.set_sensitive(False)
        self.branding_status.set_text(traducir("Aplicando tema Plymouth…"))

        self._run_authorized_action("branding-plymouth", self._branding_plymouth_done, theme,
                                    operation="Tema de arranque")

    def _branding_plymouth_done(self, ok, data):
        self.branding_plymouth_btn.set_sensitive(True)
        if not ok:
            self.branding_status.set_text(traducir("Error: %s") % data)
        else:
            success = data.get("success", False)
            self.branding_status.set_text(traducir("Plymouth actualizado.") if success else traducir("Error: %s") % data.get("message", ""))
        return GLib.SOURCE_REMOVE

    def _crear_tarjeta_wallpaper(self, wp):
        tarjeta, contenido = tarjeta_mantenimiento(8)
        tarjeta.set_size_request(330, -1)

        try:
            pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(wp["path"], 200, 120, True)
            imagen = Gtk.Image.new_from_pixbuf(pixbuf)
        except GLib.Error:
            imagen = Gtk.Image.new_from_icon_name("image-x-generic", Gtk.IconSize.DIALOG)
        contenido.pack_start(imagen, False, False, 0)

        titulo = etiqueta(wp["name"])
        titulo.get_style_context().add_class("aio-heading")
        contenido.pack_start(titulo, False, False, 0)

        btn = Gtk.Button(label=traducir("Usar este fondo"))
        btn.connect("clicked", self._branding_set_wallpaper, wp["path"])
        contenido.pack_start(btn, False, False, 0)

        return tarjeta
